export type Language = 'ar' | 'en';

export interface Service {
  id: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  icon: string;
  featuresAr: string[];
  featuresEn: string[];
  category: 'accounting' | 'enterprise' | 'retail' | 'medical' | 'education' | 'web_mobile' | 'ai_dev' | 'support';
}

export interface Project {
  id: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  longDescriptionAr: string;
  longDescriptionEn: string;
  category: 'accounting' | 'erp' | 'pos' | 'medical' | 'web' | 'mobile' | 'ai';
  image: string;
  techStack: string[];
  screensCount: number;
  database: string;
  performanceScore: string;
  securityRating: string;
  durationWeeks: number;
  clientNameAr: string;
  clientNameEn: string;
  clientFeedbackAr: string;
  clientFeedbackEn: string;
  clientRating: number;
  featuresAr: string[];
  featuresEn: string[];
  images: string[];
  videoUrl?: string;
}

export interface BlogPost {
  id: string;
  titleAr: string;
  titleEn: string;
  contentAr: string;
  contentEn: string;
  category: string;
  authorAr: string;
  authorEn: string;
  date: string;
  image: string;
  tags: string[];
  views: number;
}

export interface DownloadItem {
  id: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  fileSize: string;
  version: string;
  type: 'installer' | 'pdf' | 'excel_template';
  downloadUrl: string;
  downloadsCount: number;
}

export interface ProjectRequest {
  id: string;
  clientName: string;
  email: string;
  phone: string;
  projectType: string;
  budget: string;
  duration: string;
  description: string;
  features: string[];
  colorTheme: string;
  hasLogo: boolean;
  status: 'pending' | 'reviewing' | 'approved' | 'in_progress' | 'completed';
  createdAt: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  status: 'unread' | 'read' | 'replied';
  createdAt: string;
}

export interface JobApplication {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  position: string;
  experienceYears: number;
  portfolioUrl?: string;
  coverLetter: string;
  resumeFileName?: string;
  status: 'applied' | 'interviewing' | 'accepted' | 'rejected';
  createdAt: string;
}

export interface ClientProjectState {
  id: string;
  titleAr: string;
  titleEn: string;
  clientEmail: string;
  clientName: string;
  progress: number; // 0-100
  status: 'planning' | 'development' | 'testing' | 'delivery' | 'completed';
  invoices: {
    id: string;
    amount: number;
    dueDate: string;
    status: 'paid' | 'unpaid';
  }[];
  updates: {
    date: string;
    titleAr: string;
    titleEn: string;
    descriptionAr: string;
    descriptionEn: string;
  }[];
  chatHistory: {
    sender: 'client' | 'support';
    message: string;
    timestamp: string;
  }[];
  contracts?: {
    id: string;
    titleAr: string;
    titleEn: string;
    signDate: string;
    status: 'signed' | 'review';
    downloadUrl: string;
  }[];
  latestBuilds?: {
    version: string;
    releaseDate: string;
    notesAr: string;
    notesEn: string;
    fileSize: string;
    downloadUrl: string;
  }[];
  supportTickets?: {
    id: string;
    subjectAr: string;
    subjectEn: string;
    status: 'open' | 'resolved';
    createdAt: string;
  }[];
}
