import React from 'react';
import { Send, Sparkles, CheckCircle, Smartphone, Globe, Shield, RefreshCw, Layers } from 'lucide-react';
import { Language, ProjectRequest } from '../types';

interface ProjectEstimatorProps {
  language: Language;
  onRequestSubmitted?: () => void;
}

export default function ProjectEstimator({ language, onRequestSubmitted }: ProjectEstimatorProps) {
  const [step, setStep] = React.useState<number>(1);
  const [projectType, setProjectType] = React.useState<string>('accounting');
  const [budget, setBudget] = React.useState<string>('$1500 - $3000');
  const [duration, setDuration] = React.useState<string>('4 - 8 Weeks');
  const [selectedFeatures, setSelectedFeatures] = React.useState<string[]>([]);
  const [colorTheme, setColorTheme] = React.useState<string>('blue');
  const [hasLogo, setHasLogo] = React.useState<boolean>(false);
  
  // Client details
  const [clientName, setClientName] = React.useState<string>('');
  const [email, setEmail] = React.useState<string>('');
  const [phone, setPhone] = React.useState<string>('');
  const [description, setDescription] = React.useState<string>('');

  const [submitted, setSubmitted] = React.useState<boolean>(false);

  const featuresList = [
    { id: 'vat', labelAr: 'الفاتورة الإلكترونية والضرائب', labelEn: 'VAT & E-Invoicing' },
    { id: 'backup', labelAr: 'نسخ احتياطي تلقائي سحابي', labelEn: 'Automatic Cloud Backups' },
    { id: 'multilang', labelAr: 'دعم ثنائي اللغة (عربي/إنجليزي)', labelEn: 'Dual-language Support' },
    { id: 'payment', labelAr: 'بوابات الدفع الإلكتروني والفيزا', labelEn: 'Online Payment Gateways' },
    { id: 'sms', labelAr: 'إشعارات SMS وتنبيهات تلقائية', labelEn: 'SMS & WhatsApp Alerts' },
    { id: 'offline', labelAr: 'التشغيل دون اتصال بالإنترنت', labelEn: 'Offline Operations Support' }
  ];

  const handleFeatureToggle = (id: string) => {
    if (selectedFeatures.includes(id)) {
      setSelectedFeatures(selectedFeatures.filter(f => f !== id));
    } else {
      setSelectedFeatures([...selectedFeatures, id]);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName || !email || !phone) {
      alert(language === 'ar' ? 'يرجى ملء كافة البيانات الأساسية للتواصل.' : 'Please fill all basic contact details.');
      return;
    }

    const newRequest: ProjectRequest = {
      id: `REQ-${Math.floor(100000 + Math.random() * 900000)}`,
      clientName,
      email,
      phone,
      projectType,
      budget,
      duration,
      description,
      features: selectedFeatures,
      colorTheme,
      hasLogo,
      status: 'pending',
      createdAt: new Date().toISOString().split('T')[0]
    };

    // Save to LocalStorage
    const currentRequests = JSON.parse(localStorage.getItem('barmegny_project_requests') || '[]');
    localStorage.setItem('barmegny_project_requests', JSON.stringify([newRequest, ...currentRequests]));

    setSubmitted(true);
    if (onRequestSubmitted) {
      onRequestSubmitted();
    }
  };

  const resetForm = () => {
    setStep(1);
    setProjectType('accounting');
    setBudget('$1500 - $3000');
    setDuration('4 - 8 Weeks');
    setSelectedFeatures([]);
    setColorTheme('blue');
    setHasLogo(false);
    setClientName('');
    setEmail('');
    setPhone('');
    setDescription('');
    setSubmitted(false);
  };

  const getTypeIcon = (id: string) => {
    switch (id) {
      case 'accounting': return <Layers className="w-4 h-4" />;
      case 'erp': return <Shield className="w-4 h-4" />;
      case 'pos': return <RefreshCw className="w-4 h-4 animate-pulse" />;
      case 'medical': return <Sparkles className="w-4 h-4" />;
      case 'web': return <Globe className="w-4 h-4" />;
      case 'mobile': return <Smartphone className="w-4 h-4" />;
      default: return <Layers className="w-4 h-4" />;
    }
  };

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto my-12 p-8 rounded-3xl glass-panel text-center space-y-6 shadow-xl relative overflow-hidden animate-fadeIn">
        <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-blue-500"></div>
        <div className="h-16 w-16 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto border border-emerald-500/20">
          <CheckCircle size={36} />
        </div>
        <h3 className="text-2xl font-black text-slate-900 dark:text-white">
          {language === 'ar' ? 'تم إرسال طلبك بنجاح!' : 'Request Placed Successfully!'}
        </h3>
        <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed font-light">
          {language === 'ar'
            ? 'شكراً لتواصلك مع برمجني. تم استلام طلبك وبدأ المهندس يوسف بلح وفريق العمل في مراجعته وسنتواصل معك عبر الهاتف أو الواتساب خلال 24 ساعة لتقديم عرض سعر تفصيلي.'
            : 'Thank you for choosing Barmegny. Eng. Youssef Balah and his engineering team have received your proposal and will contact you via WhatsApp or Email within 24 hours.'}
        </p>
        <button
          type="button"
          onClick={resetForm}
          className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm transition-all cursor-pointer shadow-lg shadow-blue-500/20"
        >
          {language === 'ar' ? 'تقديم طلب جديد' : 'Submit Another Request'}
        </button>
      </div>
    );
  }

  return (
    <div className="py-20 bg-transparent transition-colors duration-300">
      <div className="max-w-4xl mx-auto px-4">
        
        {/* Header Title */}
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <span className="text-xs font-black uppercase text-blue-600 dark:text-blue-400 tracking-wider">
            {language === 'ar' ? 'حاسبة المشاريع الذكية' : 'Smart Pricing Calculator'}
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white">
            {language === 'ar' ? 'اطلب مشروعك البرمجي' : 'Order Your Bespoke System'}
          </h2>
          <p className="text-slate-600 dark:text-slate-400 font-light text-sm sm:text-base">
            {language === 'ar'
              ? 'حدد تفاصيل نظامك، ميزانيتك، والميزات المطلوبة لتتلقى دراسة فورية وعرض سعر مخصص من الإدارة.'
              : 'Select your software layers, budget boundaries, and custom features to receive a prompt proposal.'}
          </p>
        </div>

        {/* Step Indicator Bar */}
        <div className="flex items-center justify-center gap-2 mb-10 text-xs font-bold text-slate-400">
          <span className={`h-8 w-8 rounded-full flex items-center justify-center font-extrabold transition-all ${step >= 1 ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25' : 'bg-white text-slate-600 border border-slate-200 dark:bg-white/5 dark:text-slate-300 dark:border-white/10'}`}>1</span>
          <div className={`h-0.5 w-12 transition-all duration-300 ${step >= 2 ? 'bg-blue-600' : 'bg-slate-200 dark:bg-white/10'}`}></div>
          <span className={`h-8 w-8 rounded-full flex items-center justify-center font-extrabold transition-all ${step >= 2 ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25' : 'bg-white text-slate-600 border border-slate-200 dark:bg-white/5 dark:text-slate-300 dark:border-white/10'}`}>2</span>
          <div className={`h-0.5 w-12 transition-all duration-300 ${step === 3 ? 'bg-blue-600' : 'bg-slate-200 dark:bg-white/10'}`}></div>
          <span className={`h-8 w-8 rounded-full flex items-center justify-center font-extrabold transition-all ${step === 3 ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25' : 'bg-white text-slate-600 border border-slate-200 dark:bg-white/5 dark:text-slate-300 dark:border-white/10'}`}>3</span>
        </div>

        {/* Form Container Card with Adaptive Genius Glass Design */}
        <div className="glass-panel rounded-3xl shadow-xl p-6 sm:p-10 relative overflow-hidden">
          
          {/* Genius Top Glowing Frame Line */}
          <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 rounded-t-3xl"></div>
          
          {/* STEP 1: Project Type and Specs */}
          {step === 1 && (
            <div className="space-y-8 animate-fadeIn">
              <div className="space-y-4">
                <label className="text-base font-black text-slate-900 dark:text-white block">
                  {language === 'ar' ? '1. ما هو نوع البرنامج أو النظام المطلوب؟' : '1. What is your desired software category?'}
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    { id: 'accounting', labelAr: 'برنامج محاسبي', labelEn: 'Accounting App' },
                    { id: 'erp', labelAr: 'نظام ERP كامل', labelEn: 'Full ERP System' },
                    { id: 'pos', labelAr: 'كاشير ونقاط بيع POS', labelEn: 'Cashier & POS' },
                    { id: 'medical', labelAr: 'إدارة صيدلية / عيادة', labelEn: 'Medical / Pharmacy' },
                    { id: 'web', labelAr: 'موقع أو متجر إلكتروني', labelEn: 'Website / E-Commerce' },
                    { id: 'mobile', labelAr: 'تطبيق هاتف Android/iOS', labelEn: 'Mobile Application' }
                  ].map((type) => {
                    const isSelected = projectType === type.id;
                    return (
                      <button
                        key={type.id}
                        type="button"
                        onClick={() => setProjectType(type.id)}
                        className={`p-4 rounded-2xl text-xs sm:text-sm font-extrabold border flex flex-col items-center justify-center gap-3 transition-all duration-300 cursor-pointer interactive-card ${
                          isSelected
                            ? 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white border-transparent shadow-lg shadow-blue-500/25 ring-2 ring-blue-500/30'
                            : 'border-slate-200/80 bg-white/40 text-slate-700 hover:bg-white/80 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:bg-white/10'
                        }`}
                      >
                        <div className={`p-2 rounded-xl transition-colors ${isSelected ? 'bg-white/10 text-white' : 'bg-blue-600/5 text-blue-600 dark:bg-blue-400/10 dark:text-blue-400'}`}>
                          {getTypeIcon(type.id)}
                        </div>
                        <span>{language === 'ar' ? type.labelAr : type.labelEn}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Budget Picker */}
              <div className="space-y-4">
                <label className="text-base font-black text-slate-900 dark:text-white block">
                  {language === 'ar' ? '2. الميزانية التقديرية المرصودة للمشروع' : '2. Your allocated budget bracket'}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { id: '$1500 - $3000', descAr: 'مناسبة للمشاريع البسيطة والمتاجر', descEn: 'Suitable for simple sites & stores' },
                    { id: '$3000 - $7000', descAr: 'مثالية لنقاط البيع والمنظومات', descEn: 'Perfect for local POS & Clinics' },
                    { id: '$7000+', descAr: 'مخصصة لأنظمة ERP الضخمة والفروع', descEn: 'Bespoke multi-branch ERP solutions' }
                  ].map((bracket) => {
                    const isSelected = budget === bracket.id;
                    return (
                      <button
                        key={bracket.id}
                        type="button"
                        onClick={() => setBudget(bracket.id)}
                        className={`p-4 rounded-2xl border text-right sm:text-center space-y-1.5 transition-all duration-300 cursor-pointer interactive-card ${
                          isSelected
                            ? 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white border-transparent shadow-lg shadow-blue-500/25 ring-2 ring-blue-500/30'
                            : 'border-slate-200/80 bg-white/40 text-slate-700 hover:bg-white/80 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:bg-white/10'
                        }`}
                      >
                        <span className="block text-sm sm:text-base font-black tracking-tight">{bracket.id}</span>
                        <span className={`block text-[10px] leading-relaxed font-light ${isSelected ? 'text-white/90' : 'text-slate-500 dark:text-slate-400'}`}>
                          {language === 'ar' ? bracket.descAr : bracket.descEn}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Delivery Duration */}
              <div className="space-y-4">
                <label className="text-base font-black text-slate-900 dark:text-white block">
                  {language === 'ar' ? '3. مدة التنفيذ المستهدفة' : '3. Targeted Delivery Timeline'}
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {['2 - 4 Weeks', '4 - 8 Weeks', '2+ Months'].map((dur) => {
                    const isSelected = duration === dur;
                    return (
                      <button
                        key={dur}
                        type="button"
                        onClick={() => setDuration(dur)}
                        className={`p-3.5 rounded-2xl border text-center text-xs sm:text-sm font-extrabold transition-all duration-300 cursor-pointer interactive-card ${
                          isSelected
                            ? 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white border-transparent shadow-md shadow-blue-500/25'
                            : 'border-slate-200/80 bg-white/40 text-slate-700 hover:bg-white/80 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:bg-white/10'
                        }`}
                      >
                        {dur}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="pt-4 text-left">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-8 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm transition-all cursor-pointer shadow-lg shadow-blue-500/20 active:scale-95"
                >
                  {language === 'ar' ? 'التالي: الميزات الإضافية' : 'Next: Custom Features'}
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Custom Modules & Branding */}
          {step === 2 && (
            <div className="space-y-8 animate-fadeIn">
              <div className="space-y-4">
                <label className="text-base font-black text-slate-900 dark:text-white block">
                  {language === 'ar' ? '4. حدد الوحدات والميزات الإضافية المطلوبة' : '4. Select modular feature additions'}
                </label>
                <div className="grid sm:grid-cols-2 gap-3">
                  {featuresList.map((feat) => {
                    const isSelected = selectedFeatures.includes(feat.id);
                    return (
                      <button
                        key={feat.id}
                        type="button"
                        onClick={() => handleFeatureToggle(feat.id)}
                        className={`p-4 rounded-2xl border text-right flex items-center justify-between gap-3 transition-all duration-300 cursor-pointer interactive-card ${
                          isSelected
                            ? 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white border-transparent shadow-md'
                            : 'border-slate-200/80 bg-white/40 text-slate-700 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 hover:bg-white/80'
                        }`}
                      >
                        <span className="text-xs sm:text-sm font-extrabold">{language === 'ar' ? feat.labelAr : feat.labelEn}</span>
                        <div className={`h-5 w-5 rounded-full border flex items-center justify-center transition-all ${isSelected ? 'bg-white text-blue-600 border-white' : 'border-slate-300 bg-white/50 dark:border-white/20'}`}>
                          {isSelected && <CheckCircle size={14} className="text-blue-600" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Brand Branding preference */}
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <label className="text-sm font-extrabold text-slate-700 dark:text-slate-300 block">
                    {language === 'ar' ? '5. اللون المفضل للهوية البصرية' : '5. Brand primary color preference'}
                  </label>
                  <div className="flex gap-2">
                    {[
                      { id: 'blue', hex: 'bg-blue-600' },
                      { id: 'emerald', hex: 'bg-emerald-600' },
                      { id: 'indigo', hex: 'bg-indigo-600' },
                      { id: 'slate', hex: 'bg-slate-900' },
                      { id: 'rose', hex: 'bg-rose-600' }
                    ].map((col) => (
                      <button
                        key={col.id}
                        type="button"
                        onClick={() => setColorTheme(col.id)}
                        className={`h-8 w-8 rounded-full ${col.hex} cursor-pointer transition-transform ${colorTheme === col.id ? 'ring-2 ring-blue-500 scale-110' : 'opacity-80'}`}
                        title={col.id}
                      ></button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-sm font-extrabold text-slate-700 dark:text-slate-300 block">
                    {language === 'ar' ? '6. هل تمتلك شعاراً (Logo) جاهزاً؟' : '6. Do you possess a ready brand Logo?'}
                  </label>
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setHasLogo(true)}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${hasLogo ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/10' : 'border-slate-200/80 bg-white/40 text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300'}`}
                    >
                      {language === 'ar' ? 'نعم، الشعار جاهز' : 'Yes, Logo is ready'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setHasLogo(false)}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${!hasLogo ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/10' : 'border-slate-200/80 bg-white/40 text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300'}`}
                    >
                      {language === 'ar' ? 'لا، أحتاج تصميم شعار' : 'No, I need a Logo designed'}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-4 justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-6 py-3 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-white/10 dark:text-slate-300 dark:hover:bg-white/10 font-bold text-sm transition-all cursor-pointer"
                >
                  {language === 'ar' ? 'السابق' : 'Previous'}
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-8 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm transition-all cursor-pointer shadow-lg shadow-blue-500/20"
                >
                  {language === 'ar' ? 'التالي: بيانات التواصل' : 'Next: Contact Info'}
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Client Details */}
          {step === 3 && (
            <form onSubmit={handleFormSubmit} className="space-y-6 animate-fadeIn">
              <h3 className="text-lg font-black text-slate-900 dark:text-white border-b border-slate-100 dark:border-white/10 pb-3">
                {language === 'ar' ? '7. يرجى تزويدنا ببيانات التواصل وموجز العمل' : '7. Please submit your contact details and project summary'}
              </h3>

              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-1.5">
                  <label className="text-xs font-extrabold text-slate-600 dark:text-slate-400">{language === 'ar' ? 'الاسم الكريم' : 'Your Full Name'} *</label>
                  <input
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder={language === 'ar' ? 'مثال: أحمد عبد الله' : 'e.g. Johnathan Doe'}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200/80 bg-white/60 dark:border-white/10 dark:bg-[#05070a]/60 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-extrabold text-slate-600 dark:text-slate-400">{language === 'ar' ? 'رقم الهاتف / الواتساب' : 'WhatsApp / Mobile Number'} *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+9665..."
                    className="w-full px-4 py-3 rounded-xl border border-slate-200/80 bg-white/60 dark:border-white/10 dark:bg-[#05070a]/60 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-extrabold text-slate-600 dark:text-slate-400">{language === 'ar' ? 'البريد الإلكتروني' : 'Email Address'} *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@company.com"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200/80 bg-white/60 dark:border-white/10 dark:bg-[#05070a]/60 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-extrabold text-slate-600 dark:text-slate-400">{language === 'ar' ? 'موجز تفاصيل المشروع المطلوبة (اختياري)' : 'Brief project details or specific demands (Optional)'}</label>
                <textarea
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={language === 'ar' ? 'اكتب باخترار عن شركتك وأهداف البرنامج المطلوب...' : 'Describe what reports, modules, or outputs your team requires...'}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200/80 bg-white/60 dark:border-white/10 dark:bg-[#05070a]/60 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                ></textarea>
              </div>

              <div className="flex items-center gap-3 justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-6 py-3 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-white/10 dark:text-slate-300 dark:hover:bg-white/10 font-bold text-sm transition-all cursor-pointer"
                >
                  {language === 'ar' ? 'السابق' : 'Previous'}
                </button>
                <button
                  type="submit"
                  className="px-8 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-blue-500/20 active:scale-95"
                >
                  <Send size={16} />
                  <span>{language === 'ar' ? 'إرسال طلب النظام' : 'Submit System Request'}</span>
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
}
