import React from 'react';
import { ShoppingBag, Layers, Monitor, Calculator, Cpu, Laptop, Key, CheckCircle, Receipt, Plus, Play, Flame, Sparkles, Globe, Download, ShoppingCart, RefreshCw, Smartphone } from 'lucide-react';
import { Language } from '../types';

interface SoftwareStoreProps {
  language: Language;
}

interface StoreItem {
  id: string;
  category: 'accounting' | 'pos' | 'templates' | 'extensions' | 'apps' | 'licenses';
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  price: number;
  featuresAr: string[];
  featuresEn: string[];
  rating: number;
  badgeAr?: string;
  badgeEn?: string;
}

export default function SoftwareStore({ language }: SoftwareStoreProps) {
  // Store Categories Tab
  const [activeCategory, setActiveCategory] = React.useState<string>('all');
  
  // Instant Estimator Selection State
  const [estimatorSelected, setEstimatorSelected] = React.useState({
    accounting: false,
    pos: false,
    erp: false,
    website: false,
  });
  
  // Estimator custom features
  const [estimatorCloudSync, setEstimatorCloudSync] = React.useState(false);
  const [estimatorMultiBranch, setEstimatorMultiBranch] = React.useState(false);
  const [estimatorTaxAPI, setEstimatorTaxAPI] = React.useState(false);
  const [estimatorSupportPeriod, setEstimatorSupportPeriod] = React.useState('6'); // '6' or '12' or '24' months
  
  // Live Demo Simulator Active Selection
  const [activeDemo, setActiveDemo] = React.useState<'pos' | 'accounting' | 'template'>('pos');
  
  // POS Live Demo Local Simulator States
  const [posCart, setPosCart] = React.useState<{ nameAr: string; nameEn: string; price: number; qty: number }[]>([]);
  const [posDiscount, setPosDiscount] = React.useState<number>(0);
  const [posInvoiceNumber, setPosInvoiceNumber] = React.useState<string>('INV-8024');
  const [posIsPaid, setPosIsPaid] = React.useState<boolean>(false);
  
  // Accounting Live Demo States
  const [accEntries, setAccEntries] = React.useState<{ descAr: string; descEn: string; debit: number; credit: number }[]>([
    { descAr: 'رأس مال البداية', descEn: 'Initial Paid-up Capital', debit: 0, credit: 50000 },
    { descAr: 'شراء أجهزة سيرفرات ومعدات', descEn: 'Server & Hardware Purchase', debit: 12000, credit: 0 },
    { descAr: 'إيراد مبيعات ترخيص كاشير', descEn: 'License Sales Revenue', debit: 0, credit: 4500 },
    { descAr: 'دفعة عقد عيادات الأمل', descEn: 'Al-Amal Clinics Project Milestone', debit: 0, credit: 1500 },
    { descAr: 'مصروفات استضافة سحابية AWS', descEn: 'Cloud AWS Hosting Expense', debit: 350, credit: 0 },
  ]);
  const [newAccDesc, setNewAccDesc] = React.useState('');
  const [newAccType, setNewAccType] = React.useState<'debit' | 'credit'>('debit');
  const [newAccAmount, setNewAccAmount] = React.useState('');

  // Web Template Live Sandbox
  const [sandboxColor, setSandboxColor] = React.useState<'blue' | 'purple' | 'emerald' | 'amber'>('blue');
  const [sandboxTheme, setSandboxTheme] = React.useState<'light' | 'dark'>('dark');
  const [sandboxLayout, setSandboxLayout] = React.useState<'grid' | 'list'>('grid');

  // Store Items Data
  const storeItems: StoreItem[] = [
    {
      id: 'acc-pro',
      category: 'accounting',
      titleAr: 'برنامج برمجني للمحاسبة السحابية Pro',
      titleEn: 'Barmegny Accounting Cloud Pro',
      descriptionAr: 'منظومة حسابات احترافية متكاملة للمؤسسات المتوسطة، يدعم القيود ومطابقة كشوفات البنوك والتقارير الختامية بضغطة زر.',
      descriptionEn: 'Full-featured enterprise financial suite supporting dual-ledger posting, balance sheets, and bank reconciliations.',
      price: 299,
      rating: 4.9,
      badgeAr: 'الأكثر مبيعاً',
      badgeEn: 'Best Seller',
      featuresAr: ['شجرة حسابات غير محدودة المستويات', 'مطابقة تلقائية لكشوفات البنوك', 'تقارير الأرباح والخسائر والميزانية', 'دعم ضريبي كامل'],
      featuresEn: ['Unlimited chart of accounts', 'Automated bank imports', 'Comprehensive Balance Sheet / P&L', '100% Tax Compliant']
    },
    {
      id: 'pos-retail',
      category: 'pos',
      titleAr: 'منظومة كاشير برمجني POS لقطاع التجزئة',
      titleEn: 'Barmegny Retail POS System',
      descriptionAr: 'برنامج نقاط بيع فائق السرعة يدعم الباركود والموازين وتعدد طابعات الكاشير والعمل بالكامل دون اتصال بالإنترنت.',
      descriptionEn: 'High-speed retail checkout system. Operates offline seamlessly with barcode scanning, barcode generation, and thermal printing.',
      price: 199,
      rating: 4.8,
      badgeAr: 'تشغيل أوفلاين',
      badgeEn: 'Offline Active',
      featuresAr: ['شاشة مبيعات تفاعلية باللمس', 'نظام جرد وجدول كميات متطور', 'إصدار باركود تلقائي للمنتجات', 'دعم ربط ميزان الباركود'],
      featuresEn: ['Interactive touchscreen layout', 'Advanced stock levels tracker', 'Direct label/barcode printing', 'Digital scale integrations']
    },
    {
      id: 'pos-restaurant',
      category: 'pos',
      titleAr: 'نظام إدارة المطاعم والكافيهات المتكامل',
      titleEn: 'Barmegny Restaurant POS Master',
      descriptionAr: 'إصدار مخصص للمطاعم يضم لوحة الطاولات، شاشات المطبخ، متابعة الدليفري والتوصيل، ونظام QR للطلب الذاتي.',
      descriptionEn: 'Tailored dining & cafe software including table layout screens, kitchen display units, driver dispatches, and QR menus.',
      price: 249,
      rating: 4.9,
      badgeAr: 'شاشات المطبخ',
      badgeEn: 'Kitchen Screens',
      featuresAr: ['توزيع الطاولات والطلبات الذكية', 'شاشات تحضير المطبخ اللحظية', 'إدارة الوصفات والتكاليف Recipes', 'إدارة الدليفري وعمولات الطيارين'],
      featuresEn: ['Dynamic floor table configurations', 'Live digital kitchen displays', 'Ingredient costings & recipe logs', 'Driver dispatch & tracking']
    },
    {
      id: 'template-agency',
      category: 'templates',
      titleAr: 'قالب موقع الشركات والوكالات العصرية',
      titleEn: 'Modern Corporate Agency Template',
      descriptionAr: 'قالب موقع تعريفي تفاعلي فائق السرعة مبني بأحدث تقنيات Next.js و Tailwind CSS وتأثيرات Framer Motion الإبداعية.',
      descriptionEn: 'Sleek, high-converting agency portfolio template. Programmed using Next.js, Tailwind CSS, and Framer Motion.',
      price: 49,
      rating: 4.7,
      badgeAr: 'Next.js 15',
      badgeEn: 'Next.js 15',
      featuresAr: ['سرعة تحميل صاروخية 100% سكير', 'دعم كامل لمحركات البحث SEO', 'تأثيرات حركية خيالية', 'لوحة تحكم إدارية مصغرة'],
      featuresEn: ['100% PageSpeed performance score', 'SEO Semantic layouts', 'Smooth interactive transitions', 'Mini administrative panel']
    },
    {
      id: 'template-ecommerce',
      category: 'templates',
      titleAr: 'قالب متجر إلكتروني ذكي متعدد الفروع',
      titleEn: 'Multi-Branch Smart E-Shop Template',
      descriptionAr: 'قالب متجر متكامل يضم سلة مشتريات ذكية، صفحة دفع احترافية، وربط متكامل مع Paymob و Paytabs.',
      descriptionEn: 'Robust, gorgeous e-commerce store with rapid checkout flow and fully-baked Paymob, Stripe, and Paytabs adapters.',
      price: 89,
      rating: 4.8,
      badgeAr: 'بوابات الدفع',
      badgeEn: 'Payments Ready',
      featuresAr: ['سلة شراء ديناميكية بالكامل', 'لوحة تحكم إدارة السلع والمشترين', 'دعم الدفع الإلكتروني والتقسيط', 'نظام أكواد خصم ذكي'],
      featuresEn: ['Fully dynamic checkout cart', 'Stunning catalog and order logs', 'Installments & card gateways', 'Coupon & discount systems']
    },
    {
      id: 'ext-invoice-api',
      category: 'extensions',
      titleAr: 'إضافة الربط التلقائي بالفاتورة الإلكترونية',
      titleEn: 'Tax E-Invoicing API Connector',
      descriptionAr: 'إضافة برمجية للربط المباشر مع مصلحة الضرائب لرفع الفواتير وإصدار التوقيع الإلكتروني آلياً.',
      descriptionEn: 'Seamless middleware module linking your software directly to regional tax authorities for real-time compliance.',
      price: 120,
      rating: 4.9,
      badgeAr: 'ربط ضرائب معتمد',
      badgeEn: 'ZATCA / Tax Ready',
      featuresAr: ['ربط مباشر عبر الـ API الرسمي', 'إرسال الفواتير بصيغة XML و JSON', 'توقيع إلكتروني مشفر وآمن', 'تحديث فوري لحالة الإرسال'],
      featuresEn: ['Direct API authentication', 'JSON & XML generation', 'Secure cryptographic signatures', 'Live transfer status loops']
    },
    {
      id: 'ext-whatsapp-alert',
      category: 'extensions',
      titleAr: 'إضافة الإشعارات الفورية والواتساب التلقائي',
      titleEn: 'WhatsApp & SMS Alert Gateway',
      descriptionAr: 'إرسال فواتير المبيعات، سندات القبض، ورسائل ترحيب العملاء تلقائياً برقم شركتك عبر الواتساب والرسائل القصيرة.',
      descriptionEn: 'Auto-broadcast sales invoices, receipt vouchers, and customer greetings directly to your clients WhatsApp instantly.',
      price: 79,
      rating: 4.6,
      featuresAr: ['ربط مباشر مع WhatsApp Cloud API', 'إرسال تلقائي لحظة حفظ الفاتورة', 'قوالب رسائل قابلة للتخصيص الكامل', 'إحصائيات لتسليم الرسائل وقراءتها'],
      featuresEn: ['Official WhatsApp API connector', 'Instant triggers upon saving sales', 'Fully customizable templates', 'Delivery and read receipts logs']
    },
    {
      id: 'lic-accounting-annual',
      category: 'licenses',
      titleAr: 'ترخيص سنوي معتمد - خادم برمجني الرئيسي',
      titleEn: 'Annual Enterprise Server License',
      descriptionAr: 'ترخيص تشغيل خادم الحسابات الرئيسي السنوي، يغطي التحديثات الدورية والأمنية والدعم الفني الساخن 24/7.',
      descriptionEn: 'Main database node annual production license, covering periodic updates, critical patches, and priority 24/7 technical hotlines.',
      price: 350,
      rating: 5.0,
      badgeAr: 'ضمان كامل',
      badgeEn: 'Full Warranty',
      featuresAr: ['تحديثات مستمرة للنظام الحسابي', 'دعم فني عبر الهاتف والإنترنت', 'حفظ بنسخ احتياطية يومية مشفرة', 'دعم فني طارئ في العطلات'],
      featuresEn: ['Continuous software upgrades', 'Phone, chat, and remote support', 'Daily encrypted system backups', 'Emergency holiday SLA backups']
    }
  ];

  // Filters items by category selection
  const filteredItems = activeCategory === 'all' 
    ? storeItems 
    : storeItems.filter(item => item.category === activeCategory);

  // Estimator Price Calculations
  const calculateEstimatorPrice = () => {
    let base = 0;
    if (estimatorSelected.accounting) base += 450;
    if (estimatorSelected.pos) base += 300;
    if (estimatorSelected.erp) base += 1200;
    if (estimatorSelected.website) base += 250;

    // Custom features
    if (estimatorCloudSync) base += 100;
    if (estimatorMultiBranch) base += 200;
    if (estimatorTaxAPI) base += 150;

    // Support duration multiplier
    const supportMonths = parseInt(estimatorSupportPeriod);
    if (supportMonths === 12) base += 80;
    if (supportMonths === 24) base += 150;

    return base;
  };

  const calculatedTotal = calculateEstimatorPrice();

  // POS Live Demo actions
  const menuProducts = [
    { nameAr: 'برنامج محاسبة Pro', nameEn: 'Accounting License Pro', price: 299 },
    { nameAr: 'ترخيص كاشير POS لفرع', nameEn: 'POS Branch License', price: 199 },
    { nameAr: 'إضافة ربط الواتساب الذكي', nameEn: 'WhatsApp Alert Extension', price: 79 },
    { nameAr: 'قالب ويب تعريفي أنيق', nameEn: 'Agency Website Template', price: 49 },
    { nameAr: 'ساعة تدريب ودعم مهندس', nameEn: '1-Hour Technical Support', price: 30 }
  ];

  const addToPosCart = (prod: typeof menuProducts[0]) => {
    const existing = posCart.find(item => item.nameEn === prod.nameEn);
    if (existing) {
      setPosCart(posCart.map(item => item.nameEn === prod.nameEn ? { ...item, qty: item.qty + 1 } : item));
    } else {
      setPosCart([...posCart, { ...prod, qty: 1 }]);
    }
  };

  const removeFromPosCart = (nameEn: string) => {
    setPosCart(posCart.filter(item => item.nameEn !== nameEn));
  };

  const getPosSubtotal = () => posCart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const getPosVat = () => Math.round((getPosSubtotal() - posDiscount) * 0.15 * 10) / 10;
  const getPosTotal = () => Math.max(0, getPosSubtotal() - posDiscount + getPosVat());

  const handlePayPosInvoice = () => {
    if (posCart.length === 0) return;
    setPosIsPaid(true);
    setTimeout(() => {
      alert(language === 'ar' 
        ? `تم محاكاة عملية الدفع وإصدار الفاتورة رقم ${posInvoiceNumber} بنجاح!` 
        : `Payment simulated successfully! Invoice ${posInvoiceNumber} printed.`);
    }, 400);
  };

  const resetPosDemo = () => {
    setPosCart([]);
    setPosDiscount(0);
    setPosInvoiceNumber(`INV-${Math.floor(8000 + Math.random() * 1999)}`);
    setPosIsPaid(false);
  };

  // Accounting Ledger Actions
  const handleAddAccEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAccDesc.trim() || !newAccAmount || isNaN(Number(newAccAmount))) return;
    
    const amountVal = Math.abs(Number(newAccAmount));
    const newEntry = {
      descAr: newAccDesc,
      descEn: newAccDesc,
      debit: newAccType === 'debit' ? amountVal : 0,
      credit: newAccType === 'credit' ? amountVal : 0
    };

    setAccEntries([...accEntries, newEntry]);
    setNewAccDesc('');
    setNewAccAmount('');
  };

  const getAccDebitTotal = () => accEntries.reduce((sum, item) => sum + item.debit, 0);
  const getAccCreditTotal = () => accEntries.reduce((sum, item) => sum + item.credit, 0);
  const getAccNetProfit = () => getAccCreditTotal() - getAccDebitTotal();

  return (
    <div className="py-12 bg-transparent transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        
        {/* HERO TITLE */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/5 border border-blue-500/10 text-xs font-black text-blue-600 dark:text-blue-400">
            <ShoppingBag size={14} />
            <span>{language === 'ar' ? 'متجر البرمجيات والتراخيص المعتمدة' : 'Official Software Store & Licensing'}</span>
          </div>
          <h2 className="text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {language === 'ar' ? 'اختر وتصفح برامجنا الجاهزة للتشغيل' : 'Sleek, Production-Ready Solutions'}
          </h2>
          <p className="text-slate-600 dark:text-slate-400 font-light text-sm sm:text-base leading-relaxed">
            {language === 'ar' 
              ? 'تراخيص معتمدة لبرامج المحاسبة، الكاشير ونقاط البيع، مع إمكانية تجربة البرامج مباشرة وحساب عروض الأسعار فورياً.' 
              : 'Buy certified retail POS packages, accounting cloud suites, websites, extensions, and annual updates with local offline deployment support.'}
          </p>
        </div>

        {/* SECTION 1: INSTANT AUTOMATED PRICING ESTIMATOR */}
        <div className="grid lg:grid-cols-12 gap-8 items-stretch">
          
          <div className="lg:col-span-7 space-y-6">
            <div className="glass-panel rounded-3xl p-6 sm:p-8 space-y-6 relative overflow-hidden">
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-blue-600 to-indigo-600"></div>
              
              <div className="space-y-1">
                <span className="text-[10px] font-black uppercase text-blue-600 dark:text-blue-400 tracking-wider">
                  {language === 'ar' ? 'نظام عروض أسعار ذكي وتلقائي' : 'Real-time Proposal Builder'}
                </span>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">
                  {language === 'ar' ? 'احسب قيمة نظامك المخصص بنفسك' : 'Build Your Price In 2 Seconds'}
                </h3>
                <p className="text-xs text-slate-500 font-light">
                  {language === 'ar' 
                    ? 'اختر الأنظمة المطلوبة والخيارات الإضافية ليتم تجميع وحساب السعر تلقائياً.' 
                    : 'Check systems and modular add-ons below to auto-calculate your direct cost instantly.'}
                </p>
              </div>

              {/* Checkbox Grid */}
              <div className="grid sm:grid-cols-2 gap-3.5">
                {[
                  { id: 'accounting', labelAr: '✔ محاسبة مالية متميزة', labelEn: '✔ Smart Accounting Layer', price: '$450' },
                  { id: 'pos', labelAr: '✔ كاشير ونقاط بيع POS', labelEn: '✔ Fast POS Checkout', price: '$300' },
                  { id: 'erp', labelAr: '✔ تخطيط موارد كامل ERP', labelEn: '✔ Enterprise ERP Hub', price: '$1200' },
                  { id: 'website', labelAr: '✔ موقع تعريفي أو متجر', labelEn: '✔ Digital Web Presence', price: '$250' }
                ].map((syst) => {
                  const isSelected = estimatorSelected[syst.id as keyof typeof estimatorSelected];
                  return (
                    <button
                      key={syst.id}
                      type="button"
                      onClick={() => setEstimatorSelected({ ...estimatorSelected, [syst.id]: !isSelected })}
                      className={`p-4 rounded-2xl border text-right sm:text-left flex items-center justify-between gap-3 transition-all duration-300 cursor-pointer interactive-card ${
                        isSelected
                          ? 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white border-transparent shadow-md'
                          : 'border-slate-200/80 bg-white/40 text-slate-700 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 hover:bg-white/80'
                      }`}
                    >
                      <span className="text-xs sm:text-sm font-extrabold">{language === 'ar' ? syst.labelAr : syst.labelEn}</span>
                      <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${isSelected ? 'bg-white/20 text-white' : 'bg-blue-500/10 text-blue-600 dark:text-blue-400'}`}>
                        {syst.price}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Modular Features Addons */}
              <div className="space-y-3.5 border-t border-slate-100 dark:border-white/10 pt-4">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">{language === 'ar' ? 'الوحدات الإضافية المتاحة للدمج:' : 'Select Core Plugins:'}</span>
                <div className="grid sm:grid-cols-3 gap-3">
                  <label className="flex items-center gap-2 p-3 rounded-xl border border-slate-100 dark:border-white/10 bg-white/20 dark:bg-white/5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={estimatorCloudSync}
                      onChange={(e) => setEstimatorCloudSync(e.target.checked)}
                      className="rounded text-blue-600 h-4 w-4"
                    />
                    <div className="flex flex-col">
                      <span className="font-bold">{language === 'ar' ? 'مزامنة سحابية' : 'Cloud Sync'}</span>
                      <span className="text-[9px] text-slate-400">+$100</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-2 p-3 rounded-xl border border-slate-100 dark:border-white/10 bg-white/20 dark:bg-white/5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={estimatorMultiBranch}
                      onChange={(e) => setEstimatorMultiBranch(e.target.checked)}
                      className="rounded text-blue-600 h-4 w-4"
                    />
                    <div className="flex flex-col">
                      <span className="font-bold">{language === 'ar' ? 'تعدد فروع ومخازن' : 'Multi-branch'}</span>
                      <span className="text-[9px] text-slate-400">+$200</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-2 p-3 rounded-xl border border-slate-100 dark:border-white/10 bg-white/20 dark:bg-white/5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={estimatorTaxAPI}
                      onChange={(e) => setEstimatorTaxAPI(e.target.checked)}
                      className="rounded text-blue-600 h-4 w-4"
                    />
                    <div className="flex flex-col">
                      <span className="font-bold">{language === 'ar' ? 'الربط الضريبي API' : 'Tax API Hook'}</span>
                      <span className="text-[9px] text-slate-400">+$150</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* Support & SLA Tier */}
              <div className="grid sm:grid-cols-2 gap-4 border-t border-slate-100 dark:border-white/10 pt-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">{language === 'ar' ? 'مدة الدعم الفني والضمان المعتمد:' : 'Included SLA Support Level:'}</label>
                  <select
                    value={estimatorSupportPeriod}
                    onChange={(e) => setEstimatorSupportPeriod(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#05070a] text-xs text-slate-700 dark:text-slate-300 focus:outline-none"
                  >
                    <option value="6">{language === 'ar' ? '6 أشهر (دعم قياسي مجاني)' : '6 Months SLA (Standard Included)'}</option>
                    <option value="12">{language === 'ar' ? '12 شهراً (دعم هاتف وتحديثات) +$80' : '12 Months SLA (Priority Care) +$80'}</option>
                    <option value="24">{language === 'ar' ? '24 شهراً (شامل الدعم الساخن 24/7) +$150' : '24 Months SLA (Full Concierge) +$150'}</option>
                  </select>
                </div>
                <div className="flex items-end justify-end">
                  <button
                    onClick={() => {
                      if (calculatedTotal === 0) {
                        alert(language === 'ar' ? 'يرجى اختيار نظام واحد على الأقل.' : 'Please select at least one layer to quote.');
                        return;
                      }
                      alert(language === 'ar' 
                        ? `تم إنشاء عرض السعر بقيمة $${calculatedTotal} بنجاح! تم حفظ البيانات للتفاوض.`
                        : `Quote build completed for $${calculatedTotal}! This custom layout has been registered to your profile.`);
                    }}
                    className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-all shadow-md cursor-pointer"
                  >
                    {language === 'ar' ? 'تصدير عرض السعر التلقائي' : 'Export This Official Quote'}
                  </button>
                </div>
              </div>

            </div>
          </div>

          {/* Pricing Estimation Summary Output Panel */}
          <div className="lg:col-span-5">
            <div className="glass-panel rounded-3xl p-6 sm:p-8 h-full flex flex-col justify-between space-y-6 relative overflow-hidden bg-slate-900 text-white border-transparent">
              <div className="absolute top-0 inset-y-0 h-1.5 bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500"></div>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-extrabold uppercase text-cyan-400 tracking-wider">
                    {language === 'ar' ? 'مسودة عرض السعر المالي' : 'Quote Receipt Overview'}
                  </span>
                  <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded font-mono text-slate-300">
                    B-QUOTE-802
                  </span>
                </div>

                <div className="border-b border-white/10 pb-4">
                  <span className="text-3xl font-black block tracking-tight text-white flex items-baseline gap-1">
                    ${calculatedTotal}
                    <span className="text-xs font-normal text-slate-400">/ {language === 'ar' ? 'تكلفة لمرة واحدة' : 'one-time setup'}</span>
                  </span>
                </div>

                {/* Bill Breakdown list */}
                <div className="space-y-2 text-xs divide-y divide-white/5">
                  {estimatorSelected.accounting && (
                    <div className="flex justify-between pt-2">
                      <span className="text-slate-300">{language === 'ar' ? '• ترخيص الحسابات Pro الرئيسي' : '• Smart Accounting core'}</span>
                      <span className="font-mono">$450</span>
                    </div>
                  )}
                  {estimatorSelected.pos && (
                    <div className="flex justify-between pt-2">
                      <span className="text-slate-300">{language === 'ar' ? '• ترخيص الكاشير ونقاط بيع POS' : '• Retail POS License'}</span>
                      <span className="font-mono">$300</span>
                    </div>
                  )}
                  {estimatorSelected.erp && (
                    <div className="flex justify-between pt-2">
                      <span className="text-slate-300">{language === 'ar' ? '• نظام تخطيط الموارد الكامل ERP' : '• Master ERP Database'}</span>
                      <span className="font-mono">$1200</span>
                    </div>
                  )}
                  {estimatorSelected.website && (
                    <div className="flex justify-between pt-2">
                      <span className="text-slate-300">{language === 'ar' ? '• موقع تعريفي مجهز أو متجر متكامل' : '• Website / E-commerce UI'}</span>
                      <span className="font-mono">$250</span>
                    </div>
                  )}
                  {(estimatorCloudSync || estimatorMultiBranch || estimatorTaxAPI) && (
                    <div className="space-y-1.5 pt-2">
                      <span className="font-bold text-cyan-400 text-[10px] uppercase block">{language === 'ar' ? 'الوحدات الإضافية:' : 'Integrated Plugins:'}</span>
                      {estimatorCloudSync && (
                        <div className="flex justify-between text-slate-400 pl-2">
                          <span>{language === 'ar' ? 'دعم التخزين والمزامنة السحابية' : 'Cloud DB Synchronizer'}</span>
                          <span className="font-mono">+$100</span>
                        </div>
                      )}
                      {estimatorMultiBranch && (
                        <div className="flex justify-between text-slate-400 pl-2">
                          <span>{language === 'ar' ? 'ربط الفروع وقواعد البيانات الفرعية' : 'Multi-Branch Connector'}</span>
                          <span className="font-mono">+$200</span>
                        </div>
                      )}
                      {estimatorTaxAPI && (
                        <div className="flex justify-between text-slate-400 pl-2">
                          <span>{language === 'ar' ? 'التكامل مع الفاتورة الضريبية' : 'Tax Agency API'}</span>
                          <span className="font-mono">+$150</span>
                        </div>
                      )}
                    </div>
                  )}
                  {parseInt(estimatorSupportPeriod) > 6 && (
                    <div className="flex justify-between pt-2">
                      <span className="text-slate-300">{language === 'ar' ? `• تمديد الدعم الفني والـ SLA لـ ${estimatorSupportPeriod} شهراً` : `• Extended SLA for ${estimatorSupportPeriod} months`}</span>
                      <span className="font-mono">
                        {estimatorSupportPeriod === '12' ? '+$80' : '+$150'}
                      </span>
                    </div>
                  )}
                  {calculatedTotal === 0 && (
                    <div className="text-center py-6 text-slate-500 font-light text-xs">
                      {language === 'ar' ? 'يرجى تفعيل أحد خيارات الأنظمة لتوليد عرض السعر المالي.' : 'Toggle components on the left to review the financial breakdowns.'}
                    </div>
                  )}
                </div>
              </div>

              {/* Trust Badge details */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 text-xs">
                <span className="font-bold text-cyan-400 block flex items-center gap-1.5">
                  <Sparkles size={14} className="animate-spin" />
                  <span>{language === 'ar' ? 'ضمان برمجني الشامل' : 'Barmegny Assurance Policy'}</span>
                </span>
                <p className="text-[10px] text-slate-400 leading-relaxed font-light">
                  {language === 'ar' 
                    ? 'كافة أنظمتنا تشمل أكواد مصدرية نظيفة، حماية مشفرة، دعم الصيانة، والالتزام 100% بالمتطلبات التقنية والهندسية.' 
                    : 'Our software packages are fully compiled, encrypted, and backed by a 100% money-back structural coding warranty.'}
                </p>
              </div>

            </div>
          </div>

        </div>

        {/* SECTION 2: INTERACTIVE LIVE DEMO SANDBOX (TRY BEFORE BUYING) */}
        <div className="space-y-8">
          
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest">{language === 'ar' ? 'تجارب تفاعلية حية' : 'Live Interactive Simulators'}</span>
            <h3 className="text-2xl font-black text-slate-900 dark:text-white">
              {language === 'ar' ? 'جرّب برامجنا بنفسك قبل عملية الشراء' : 'Test Drive the Core Code Right Here'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-light">
              {language === 'ar' 
                ? 'انقر بين الأدوات التفاعلية أدناه لاختبار كفاءة محاكاة الكاشير وميزان الحسابات وقوالب الويب مباشرة.' 
                : 'Switch between modules below to interact with real sales checkout interfaces or bookkeeping logs directly inside this browser.'}
            </p>
          </div>

          {/* Selector Switch Tabs */}
          <div className="flex justify-center gap-2 max-w-md mx-auto">
            <button
              onClick={() => setActiveDemo('pos')}
              className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${activeDemo === 'pos' ? 'bg-blue-600 text-white shadow-lg' : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300'}`}
            >
              <Monitor size={14} />
              <span>{language === 'ar' ? 'كاشير POS' : 'POS Register'}</span>
            </button>
            <button
              onClick={() => setActiveDemo('accounting')}
              className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${activeDemo === 'accounting' ? 'bg-blue-600 text-white shadow-lg' : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300'}`}
            >
              <Calculator size={14} />
              <span>{language === 'ar' ? 'حسابات قيود' : 'Double Ledger'}</span>
            </button>
            <button
              onClick={() => setActiveDemo('template')}
              className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${activeDemo === 'template' ? 'bg-blue-600 text-white shadow-lg' : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300'}`}
            >
              <Globe size={14} />
              <span>{language === 'ar' ? 'معاينة القوالب' : 'Template Preview'}</span>
            </button>
          </div>

          {/* ACTIVE SIMULATOR CONTAINER */}
          <div className="glass-panel rounded-3xl p-6 sm:p-8 shadow-xl relative min-h-[420px] flex flex-col justify-between border-blue-500/10 dark:bg-slate-950/45">
            
            {/* 1. POS LIVE DEMO TERMINAL */}
            {activeDemo === 'pos' && (
              <div className="grid lg:grid-cols-12 gap-8 animate-fadeIn">
                
                {/* Menu items list */}
                <div className="lg:col-span-7 space-y-4">
                  <h4 className="text-sm font-black text-slate-900 dark:text-white border-b dark:border-white/5 pb-2">
                    {language === 'ar' ? 'قائمة المنتجات والتراخيص السريعة للبيع' : 'Product Terminal Menu - Click to ring up'}
                  </h4>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {menuProducts.map((prod, i) => (
                      <button
                        key={i}
                        onClick={() => addToPosCart(prod)}
                        className="p-3.5 rounded-2xl bg-white dark:bg-white/5 border border-slate-100 dark:border-white/10 text-right sm:text-left hover:border-blue-500 hover:shadow-md transition-all flex flex-col justify-between h-24 cursor-pointer"
                      >
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200">{language === 'ar' ? prod.nameAr : prod.nameEn}</span>
                        <div className="flex justify-between items-center w-full">
                          <span className="text-xs font-mono font-black text-blue-600 dark:text-blue-400">${prod.price}</span>
                          <span className="text-[9px] bg-blue-50 dark:bg-white/5 px-2 py-0.5 rounded font-bold text-blue-500">+ {language === 'ar' ? 'إضافة' : 'Add'}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Right: Printed invoice simulation receipt */}
                <div className="lg:col-span-5">
                  <div className="p-4 rounded-2xl bg-white dark:bg-[#05070a]/80 border border-slate-200 dark:border-white/10 text-xs font-mono text-slate-800 dark:text-slate-300 space-y-4 relative overflow-hidden shadow-inner">
                    <div className="text-center space-y-1">
                      <span className="text-base font-black tracking-tighter text-blue-600 block">BARMEGNY POS v4.2</span>
                      <span className="text-[9px] text-slate-400 block">{language === 'ar' ? 'تاريخ الفاتورة: اليوم' : 'Date: Current Sim Session'}</span>
                      <span className="text-[9px] text-slate-400 block">{language === 'ar' ? `رقم الفاتورة: ${posInvoiceNumber}` : `Invoice: ${posInvoiceNumber}`}</span>
                    </div>

                    <div className="border-t border-dashed border-slate-200 dark:border-white/10 pt-3 space-y-2">
                      {posCart.length === 0 ? (
                        <div className="text-center py-6 text-slate-400">
                          {language === 'ar' ? '[السلة فارغة. انقر على منتج للإدخال]' : '[Empty receipt. Click products to enter]'}
                        </div>
                      ) : (
                        posCart.map((item, i) => (
                          <div key={i} className="flex justify-between items-center text-[11px]">
                            <div className="space-y-0.5">
                              <span>{language === 'ar' ? item.nameAr : item.nameEn}</span>
                              <span className="text-[9px] text-slate-400 block">x{item.qty} @ ${item.price}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold">${item.price * item.qty}</span>
                              <button
                                onClick={() => removeFromPosCart(item.nameEn)}
                                className="text-rose-500 hover:text-rose-400 text-[10px] px-1 font-sans font-bold"
                              >
                                x
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Math results */}
                    <div className="border-t border-dashed border-slate-200 dark:border-white/10 pt-3 space-y-1.5 text-right">
                      <div className="flex justify-between text-[10px]">
                        <span>{language === 'ar' ? 'المجموع الفرعي:' : 'Subtotal:'}</span>
                        <span>${getPosSubtotal()}</span>
                      </div>
                      
                      {/* Discount selector inside the POS register */}
                      <div className="flex justify-between items-center text-[10px]">
                        <span>{language === 'ar' ? 'خصم مخصص:' : 'Simulated Discount:'}</span>
                        <div className="flex items-center gap-1">
                          <button onClick={() => setPosDiscount(Math.min(100, posDiscount + 10))} className="bg-slate-100 dark:bg-white/5 px-1.5 py-0.5 rounded text-[8px] font-sans font-bold cursor-pointer">+$10</button>
                          <button onClick={() => setPosDiscount(0)} className="bg-rose-500/10 text-rose-500 px-1 py-0.5 rounded text-[8px] font-sans font-bold cursor-pointer">C</button>
                          <span>-${posDiscount}</span>
                        </div>
                      </div>

                      <div className="flex justify-between text-[10px]">
                        <span>{language === 'ar' ? 'ضريبة القيمة المضافة 15%:' : 'VAT (15%):'}</span>
                        <span>${getPosVat()}</span>
                      </div>

                      <div className="flex justify-between text-xs font-black border-t border-slate-100 dark:border-white/5 pt-1.5 text-blue-600 dark:text-blue-400">
                        <span>{language === 'ar' ? 'المجموع النهائي الكلي:' : 'NET DUE TOTAL:'}</span>
                        <span>${getPosTotal()}</span>
                      </div>
                    </div>

                    {/* Pay trigger */}
                    {posCart.length > 0 && (
                      <div className="pt-2">
                        {posIsPaid ? (
                          <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-500 font-sans font-bold text-center animate-pulse">
                            ★★★ PAID & CLEARED ★★★
                          </div>
                        ) : (
                          <button
                            onClick={handlePayPosInvoice}
                            className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-center rounded-xl cursor-pointer"
                          >
                            {language === 'ar' ? 'إجراء الدفع والطباعة' : 'Ring Up Cash Payment'}
                          </button>
                        )}
                      </div>
                    )}

                    {posCart.length > 0 && (
                      <button
                        onClick={resetPosDemo}
                        className="w-full text-center text-slate-400 hover:text-slate-300 text-[10px] block font-sans pt-1"
                      >
                        {language === 'ar' ? 'مسح تصفير السلة' : 'Clear Register / New Sale'}
                      </button>
                    )}

                  </div>
                </div>

              </div>
            )}

            {/* 2. ACCOUNTING DOUBLE ENTRY LEDGER SIMULATOR */}
            {activeDemo === 'accounting' && (
              <div className="space-y-6 animate-fadeIn text-xs">
                <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
                  <div className="space-y-1">
                    <h4 className="text-sm font-black text-slate-900 dark:text-white">
                      {language === 'ar' ? 'دفتر القيود اليومية التفاعلي المزدوج' : 'Interactive Double-Entry General Ledger'}
                    </h4>
                    <p className="text-[11px] text-slate-400 font-light">
                      {language === 'ar' 
                        ? 'أضف قيوداً محاسبية حقيقية في المدين والدائن لترى كيف يتم حساب الأرصدة تلقائياً.' 
                        : 'Register dynamic transactions below to examine automated real-time net-income & trial balances.'}
                    </p>
                  </div>
                  <div className="flex gap-2 text-center">
                    <div className="p-2 bg-emerald-500/10 text-emerald-500 border border-emerald-500/10 rounded-xl">
                      <span className="text-[8px] font-bold block uppercase">{language === 'ar' ? 'إجمالي الدائن' : 'Credit Total'}</span>
                      <span className="font-mono text-xs font-black">${getAccCreditTotal()}</span>
                    </div>
                    <div className="p-2 bg-rose-500/10 text-rose-500 border border-rose-500/10 rounded-xl">
                      <span className="text-[8px] font-bold block uppercase">{language === 'ar' ? 'إجمالي المدين' : 'Debit Total'}</span>
                      <span className="font-mono text-xs font-black">${getAccDebitTotal()}</span>
                    </div>
                    <div className="p-2 bg-blue-500/10 text-blue-500 border border-blue-500/10 rounded-xl">
                      <span className="text-[8px] font-bold block uppercase">{language === 'ar' ? 'صافي الدخل' : 'Net Surplus'}</span>
                      <span className="font-mono text-xs font-black">${getAccNetProfit()}</span>
                    </div>
                  </div>
                </div>

                {/* Ledger input form */}
                <form onSubmit={handleAddAccEntry} className="grid grid-cols-1 sm:grid-cols-4 gap-2.5 p-3 rounded-2xl bg-white/40 dark:bg-white/5 border border-slate-100 dark:border-white/10">
                  <input
                    type="text"
                    required
                    value={newAccDesc}
                    onChange={(e) => setNewAccDesc(e.target.value)}
                    placeholder={language === 'ar' ? 'البيان (شرح الحركة المحاسبية)...' : 'Transaction description...'}
                    className="sm:col-span-2 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#05070a] text-xs focus:outline-none"
                  />
                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => setNewAccType('debit')}
                      className={`flex-1 py-1 px-2 rounded-xl border text-[10px] font-bold ${newAccType === 'debit' ? 'bg-rose-500/10 border-rose-500 text-rose-500' : 'border-slate-200/80 dark:border-white/5 dark:text-slate-400'}`}
                    >
                      {language === 'ar' ? 'مدين (مصروف)' : 'Debit (Out)'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewAccType('credit')}
                      className={`flex-1 py-1 px-2 rounded-xl border text-[10px] font-bold ${newAccType === 'credit' ? 'bg-emerald-500/10 border-emerald-500 text-emerald-500' : 'border-slate-200/80 dark:border-white/5 dark:text-slate-400'}`}
                    >
                      {language === 'ar' ? 'دائن (إيراد)' : 'Credit (In)'}
                    </button>
                  </div>
                  <div className="flex gap-1.5">
                    <input
                      type="number"
                      required
                      value={newAccAmount}
                      onChange={(e) => setNewAccAmount(e.target.value)}
                      placeholder="$..."
                      className="w-20 px-2 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#05070a] text-xs focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="flex-1 py-1 px-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs cursor-pointer"
                    >
                      {language === 'ar' ? 'إضافة قيد' : 'Post Entry'}
                    </button>
                  </div>
                </form>

                {/* Simulated database sheet list */}
                <div className="border border-slate-100 dark:border-white/10 rounded-2xl overflow-hidden bg-white/20 dark:bg-[#05070a]/40 max-h-[160px] overflow-y-auto">
                  <table className="w-full text-right sm:text-left text-[11px] font-mono select-none">
                    <thead className="bg-slate-50 dark:bg-white/5 text-slate-500">
                      <tr>
                        <th className="p-2 pl-4">{language === 'ar' ? 'البيان والحساب' : 'Account Description'}</th>
                        <th className="p-2 text-right">{language === 'ar' ? 'مدين ($)' : 'Debit (Dr)'}</th>
                        <th className="p-2 text-right pr-4">{language === 'ar' ? 'دائن ($)' : 'Credit (Cr)'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                      {accEntries.map((entry, idx) => (
                        <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-white/5">
                          <td className="p-2 pl-4 text-slate-800 dark:text-slate-200">{language === 'ar' ? entry.descAr : entry.descEn}</td>
                          <td className="p-2 text-right text-rose-500 font-bold">{entry.debit > 0 ? `$${entry.debit}` : '-'}</td>
                          <td className="p-2 text-right text-emerald-500 font-bold pr-4">{entry.credit > 0 ? `$${entry.credit}` : '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 3. WEBSITE TEMPLATE LIVE SANDBOX */}
            {activeDemo === 'template' && (
              <div className="grid lg:grid-cols-12 gap-8 animate-fadeIn text-xs">
                
                {/* Customizer Panel Controls */}
                <div className="lg:col-span-4 space-y-4">
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">{language === 'ar' ? 'لوحة تحكم وتعديل القالب السريعة' : 'Visual Design Panel'}</h4>
                  
                  {/* Theme toggler */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">{language === 'ar' ? 'السمة الأساسية:' : 'Color Theme Palette:'}</label>
                    <div className="flex gap-1.5">
                      {['blue', 'purple', 'emerald', 'amber'].map((col) => (
                        <button
                          key={col}
                          onClick={() => setSandboxColor(col as any)}
                          className={`flex-1 py-1.5 text-[9px] font-bold rounded capitalize cursor-pointer border ${sandboxColor === col ? 'bg-blue-600 text-white border-blue-600' : 'bg-white dark:bg-white/5 text-slate-600 dark:text-slate-300 dark:border-white/10'}`}
                        >
                          {col}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Dark Mode switcher */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">{language === 'ar' ? 'الوضع اللوني للمعاينة:' : 'Background Color Tone:'}</label>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => setSandboxTheme('light')}
                        className={`flex-1 py-1 px-2.5 rounded text-[10px] font-bold border cursor-pointer ${sandboxTheme === 'light' ? 'bg-slate-900 text-white' : 'bg-white dark:bg-white/5 text-slate-600 dark:text-slate-300 dark:border-white/10'}`}
                      >
                        {language === 'ar' ? 'وضع ناصع Light' : 'Clean Light Mode'}
                      </button>
                      <button
                        onClick={() => setSandboxTheme('dark')}
                        className={`flex-1 py-1 px-2.5 rounded text-[10px] font-bold border cursor-pointer ${sandboxTheme === 'dark' ? 'bg-slate-900 text-white' : 'bg-white dark:bg-white/5 text-slate-600 dark:text-slate-300 dark:border-white/10'}`}
                      >
                        {language === 'ar' ? 'وضع معتم Dark' : 'Dark Space Mode'}
                      </button>
                    </div>
                  </div>

                  {/* Layout switch */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">{language === 'ar' ? 'توزيع تخطيط السلع:' : 'Catalog Grid Layout:'}</label>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => setSandboxLayout('grid')}
                        className={`flex-1 py-1 text-[10px] font-bold rounded border cursor-pointer ${sandboxLayout === 'grid' ? 'bg-slate-900 text-white' : 'bg-white dark:bg-white/5 text-slate-600 dark:text-slate-300 dark:border-white/10'}`}
                      >
                        Grid
                      </button>
                      <button
                        onClick={() => setSandboxLayout('list')}
                        className={`flex-1 py-1 text-[10px] font-bold rounded border cursor-pointer ${sandboxLayout === 'list' ? 'bg-slate-900 text-white' : 'bg-white dark:bg-white/5 text-slate-600 dark:text-slate-300 dark:border-white/10'}`}
                      >
                        List
                      </button>
                    </div>
                  </div>

                </div>

                {/* Simulated visual mockup of the website template in iframe style */}
                <div className="lg:col-span-8">
                  <div className={`p-4 rounded-3xl border border-slate-200 dark:border-white/10 min-h-[220px] shadow-inner transition-colors duration-300 ${sandboxTheme === 'light' ? 'bg-white text-slate-900' : 'bg-[#05070a] text-white'}`}>
                    {/* Header menu inside the mockup */}
                    <div className="flex justify-between items-center border-b dark:border-white/5 pb-2 mb-4">
                      <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">MOCKUP TEMPLATE PREVIEW</span>
                      <div className="flex gap-1.5 text-[8px] font-bold">
                        <span className="hover:underline">Home</span>
                        <span>•</span>
                        <span className="hover:underline">Catalog</span>
                        <span>•</span>
                        <span className="hover:underline">Contact</span>
                      </div>
                    </div>

                    <div className="space-y-4">
                      {/* Interactive banner colored by controls */}
                      <div className={`p-4 rounded-2xl text-white space-y-1 text-center transition-all ${
                        sandboxColor === 'blue' ? 'bg-gradient-to-r from-blue-600 to-cyan-500' :
                        sandboxColor === 'purple' ? 'bg-gradient-to-r from-purple-600 to-indigo-600' :
                        sandboxColor === 'emerald' ? 'bg-gradient-to-r from-emerald-600 to-teal-500' :
                        'bg-gradient-to-r from-amber-500 to-orange-500'
                      }`}>
                        <h5 className="text-xs font-black tracking-tight">{language === 'ar' ? 'أهلاً بك في متجرنا الرقمي الجديد' : 'Transforming Global Solutions'}</h5>
                        <p className="text-[9px] font-light text-white/85">{language === 'ar' ? 'أحدث التقنيات البرمجية المهيأة لزيادة نسبة الشراء والمبيعات.' : 'Fully responsive layouts designed for maximum search performance.'}</p>
                      </div>

                      {/* Flex grid representing products items styled by customizer */}
                      <div className={sandboxLayout === 'grid' ? 'grid grid-cols-2 gap-2' : 'space-y-1.5'}>
                        {[
                          { nameAr: 'تطبيق التوصيل الذكي', nameEn: 'Super Dispatcher App', price: '$89' },
                          { nameAr: 'بوابة الدفع الشاملة', nameEn: 'Omni Payment Link', price: '$49' }
                        ].map((prod, i) => (
                          <div key={i} className="p-2.5 rounded-xl bg-slate-500/5 border border-slate-500/10 flex justify-between items-center">
                            <div className="space-y-0.5">
                              <span className="text-[9px] font-bold block">{language === 'ar' ? prod.nameAr : prod.nameEn}</span>
                              <span className="text-[8px] font-mono font-bold text-slate-400">{prod.price}</span>
                            </div>
                            <span className={`h-3 w-3 rounded-full ${
                              sandboxColor === 'blue' ? 'bg-blue-600' :
                              sandboxColor === 'purple' ? 'bg-purple-600' :
                              sandboxColor === 'emerald' ? 'bg-emerald-600' :
                              'bg-amber-500'
                            }`}></span>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                </div>

              </div>
            )}

            <div className="border-t border-slate-100 dark:border-white/5 pt-3 flex flex-col sm:flex-row justify-between items-center text-[10px] text-slate-400">
              <span>{language === 'ar' ? '★ بيئة تجارب تفاعلية آمنة ومفتوحة بالكامل لمعاينة الأكواد المصدرية' : '★ Safe client-side sandbox environments running in simulated state cycles'}</span>
              <span className="font-mono text-blue-500 dark:text-blue-400">Barmegny Tech Laboratories</span>
            </div>

          </div>
        </div>

        {/* SECTION 3: STORE CATALOG GRID */}
        <div className="space-y-8">
          
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-1">
              <span className="text-xs font-black uppercase text-blue-600 dark:text-blue-400 tracking-wider">
                {language === 'ar' ? 'أقسام متجر برمجني المعتمد' : 'Barmegny Catalog Core'}
              </span>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                {language === 'ar' ? 'تصفح البرامج والتراخيص الجاهزة' : 'Explore Certified Licenses & Addons'}
              </h3>
            </div>

            {/* Categories filter buttons */}
            <div className="flex flex-wrap gap-1">
              {[
                { id: 'all', labelAr: 'الكل', labelEn: 'All Products' },
                { id: 'accounting', labelAr: 'محاسبة', labelEn: 'Accounting' },
                { id: 'pos', labelAr: 'كاشير POS', labelEn: 'POS Systems' },
                { id: 'templates', labelAr: 'قوالب ويب', labelEn: 'Web Templates' },
                { id: 'extensions', labelAr: 'إضافات', labelEn: 'Extensions' },
                { id: 'licenses', labelAr: 'تراخيص', labelEn: 'Server Licenses' }
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer ${
                    activeCategory === cat.id
                      ? 'bg-blue-600 text-white font-extrabold shadow-md'
                      : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-white/10'
                  }`}
                >
                  {language === 'ar' ? cat.labelAr : cat.labelEn}
                </button>
              ))}
            </div>
          </div>

          {/* Catalog grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="group glass-panel rounded-3xl p-6 flex flex-col justify-between hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 relative overflow-hidden"
              >
                {item.badgeAr && (
                  <span className="absolute top-3 right-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                    {language === 'ar' ? item.badgeAr : item.badgeEn}
                  </span>
                )}

                <div>
                  <span className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">{item.category}</span>
                  <h4 className="text-base font-extrabold text-slate-900 dark:text-white mt-1.5 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {language === 'ar' ? item.titleAr : item.titleEn}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-light mt-2 leading-relaxed">
                    {language === 'ar' ? item.descriptionAr : item.descriptionEn}
                  </p>

                  <div className="mt-4 space-y-1.5">
                    {item.featuresAr.slice(0, 3).map((feat, i) => (
                      <div key={i} className="flex items-center gap-1.5 text-[10px] text-slate-600 dark:text-slate-400 font-semibold">
                        <CheckCircle size={10} className="text-blue-500 flex-shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border-t border-slate-100 dark:border-white/5 pt-4 mt-6 flex justify-between items-center">
                  <div className="space-y-0.5">
                    <span className="text-[9px] text-slate-400 font-bold block">{language === 'ar' ? 'سعر ترخيص السورس' : 'source-code cost'}</span>
                    <span className="text-xl font-mono font-black text-slate-900 dark:text-white">${item.price}</span>
                  </div>
                  <button
                    onClick={() => {
                      alert(language === 'ar' 
                        ? `تم تسجيل اهتمامك بمنتج: ${item.titleAr}. سيتواصل معك م. يوسف بلح لتسليم تراخيص الكود البرمجي ونظام التثبيت.` 
                        : `Thank you for your interest in: ${item.titleEn}. Eng. Youssef Balah's team will contact you shortly to ship the licensing keys.`);
                    }}
                    className="px-3.5 py-2 bg-slate-900 text-white hover:bg-slate-800 dark:bg-white/5 dark:hover:bg-white/10 dark:text-white border dark:border-white/10 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1 shadow-sm"
                  >
                    <ShoppingCart size={12} className="text-blue-500" />
                    <span>{language === 'ar' ? 'شراء التراخيص' : 'Purchase Keys'}</span>
                  </button>
                </div>

              </div>
            ))}
          </div>

        </div>

      </div>
    </div>
  );
}
