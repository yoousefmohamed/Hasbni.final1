import React from 'react';
import * as Icons from 'lucide-react';
import { services } from '../data';
import { Language, Service } from '../types';

interface ServicesProps {
  language: Language;
  onSelectService?: (service: Service) => void;
}

// Helper to resolve Lucide icons dynamically
const renderIcon = (iconName: string) => {
  const IconComponent = (Icons as any)[iconName];
  if (IconComponent) {
    return <IconComponent className="h-6 w-6 text-blue-600 dark:text-blue-400" />;
  }
  return <Icons.Cpu className="h-6 w-6 text-blue-600 dark:text-blue-400" />;
};

export default function Services({ language, onSelectService }: ServicesProps) {
  const [selectedCategory, setSelectedCategory] = React.useState<string>('all');

  const categories = [
    { id: 'all', labelAr: 'الكل', labelEn: 'All Services' },
    { id: 'accounting_erp', labelAr: 'المحاسبة والـ ERP', labelEn: 'Accounting & ERP' },
    { id: 'retail_pos', labelAr: 'نقاط البيع والكاشير', labelEn: 'Retail & POS' },
    { id: 'web_ai', labelAr: 'الويب والذكاء الاصطناعي', labelEn: 'Web & AI solutions' }
  ];

  const filteredServices = services.filter(service => {
    if (selectedCategory === 'all') return true;
    if (selectedCategory === 'accounting_erp') {
      return service.category === 'accounting' || service.category === 'enterprise';
    }
    if (selectedCategory === 'retail_pos') {
      return service.category === 'retail';
    }
    if (selectedCategory === 'web_ai') {
      return service.category === 'web_mobile' || service.category === 'ai_dev';
    }
    return true;
  });

  return (
    <section className="py-20 bg-transparent text-slate-900 dark:text-white transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Section */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {language === 'ar' ? 'خدماتنا البرمجية المبتكرة' : 'Our Innovative Software Services'}
          </h2>
          <p className="text-slate-600 dark:text-slate-400 font-light">
            {language === 'ar' 
              ? 'نقدم باقة متكاملة من الحلول الرقمية لتنظيم وإدارة أعمالك بأعلى أداء وأمان واحترافية.' 
              : 'We deliver a comprehensive suite of digital systems to orchestrate your enterprise operations with unparalleled safety and speed.'}
          </p>
          <div className="h-1 w-20 bg-blue-600 dark:bg-blue-500 mx-auto rounded-full mt-4"></div>
        </div>

        {/* Categories Tab bar */}
        <div className="flex justify-center flex-wrap gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-5 py-2.5 rounded-full text-sm font-semibold transition-all duration-200 cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20 dark:bg-blue-500'
                  : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-50 dark:bg-white/5 dark:text-slate-300 dark:border-white/10 dark:hover:bg-white/10'
              }`}
            >
              {language === 'ar' ? cat.labelAr : cat.labelEn}
            </button>
          ))}
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="group relative rounded-3xl glass-panel p-6 sm:p-8 shadow-sm hover:shadow-xl dark:hover:shadow-blue-950/5 transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between overflow-hidden"
            >
              {/* Radial Glow on Hover */}
              <div className="absolute inset-0 bg-gradient-to-tr from-blue-500/0 via-blue-500/0 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>

              <div className="space-y-6 relative z-10">
                {/* Icon Frame */}
                <div className="h-12 w-12 rounded-xl bg-blue-50 dark:bg-blue-500/10 flex items-center justify-center transition-transform group-hover:scale-110 duration-300 border border-blue-100 dark:border-blue-500/20">
                  {renderIcon(service.icon)}
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-200">
                  {language === 'ar' ? service.titleAr : service.titleEn}
                </h3>

                {/* Description */}
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed font-light">
                  {language === 'ar' ? service.descriptionAr : service.descriptionEn}
                </p>

                {/* Features list */}
                <ul className="space-y-2.5 pt-4 border-t border-slate-100 dark:border-white/10">
                  {(language === 'ar' ? service.featuresAr : service.featuresEn).map((feat, index) => (
                    <li key={index} className="flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-300">
                      <Icons.CheckCircle size={14} className="text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action */}
              <div className="pt-6 mt-6 relative z-10">
                <button
                  onClick={() => onSelectService?.(service)}
                  className="w-full flex items-center justify-center gap-1 py-3 rounded-xl text-xs font-bold text-blue-600 bg-blue-50 hover:bg-blue-600 hover:text-white dark:text-blue-400 dark:bg-white/5 dark:hover:bg-blue-600 dark:hover:text-white transition-all duration-200 cursor-pointer"
                >
                  <span>{language === 'ar' ? 'طلب تفاصيل الخدمة' : 'Request Service Details'}</span>
                  <Icons.ArrowRight size={14} className={language === 'ar' ? 'rotate-180' : ''} />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Technical Banner */}
        <div className="mt-16 rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8 sm:p-10 border border-slate-800 dark:border-white/10 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden">
          {/* Decorative internal glow */}
          <div className="absolute top-0 right-1/4 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="space-y-3 text-center md:text-right relative z-10">
            <span className="text-xs font-black uppercase tracking-wider text-blue-400">
              {language === 'ar' ? 'لماذا نعتمد التقنيات الأحدث؟' : 'Why We Choose Modern Stacks?'}
            </span>
            <h3 className="text-xl sm:text-2xl font-bold">
              {language === 'ar' 
                ? 'قوة ASP.NET Core 9 و React لإنشاء أنظمة ERP فائقة' 
                : 'Robust ASP.NET Core 9 & React for Superb ERPs'}
            </h3>
            <p className="text-sm text-slate-300 max-w-2xl font-light leading-relaxed">
              {language === 'ar' 
                ? 'تعتبر معمارية الكود النظيف (Clean Architecture) ونمط المستودعات (Repository Pattern) التي نتبعها في لغة C# الضمانة الحقيقية لأمان معلومات مؤسستك وسرعة أدائها وقابليتها للتوسع اللانهائي مستقبلاً.' 
                : 'Clean Architecture with Repository Pattern and CQRS principles in C# guarantees ultimate protection, millisecond latency, and infinite scalability for your business databases.'}
            </p>
          </div>
          <div className="flex-shrink-0 bg-[#05070a]/60 border border-slate-800 dark:border-white/10 rounded-2xl p-5 flex flex-col items-center gap-1.5 min-w-[150px] relative z-10 backdrop-blur-md">
            <span className="text-slate-400 text-[10px] uppercase tracking-wider">{language === 'ar' ? 'معيار الأداء' : 'Performance Score'}</span>
            <span className="text-3xl font-black text-amber-400">100%</span>
            <span className="text-[9px] text-slate-500">Google Lighthouse</span>
          </div>
        </div>

      </div>
    </section>
  );
}
