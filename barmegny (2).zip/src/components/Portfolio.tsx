import React from 'react';
import { Star, ShieldAlert, Cpu, CheckCircle, Clock, ExternalLink, X, Play } from 'lucide-react';
import { initialProjects } from '../data';
import { Language, Project } from '../types';

interface PortfolioProps {
  language: Language;
}

export default function Portfolio({ language }: PortfolioProps) {
  const [selectedCategory, setSelectedCategory] = React.useState<string>('all');
  const [activeProject, setActiveProject] = React.useState<Project | null>(null);

  const categories = [
    { id: 'all', labelAr: 'الكل', labelEn: 'All Projects' },
    { id: 'erp', labelAr: 'أنظمة ERP', labelEn: 'ERP Systems' },
    { id: 'pos', labelAr: 'أنظمة كاشير POS', labelEn: 'Cashier POS' },
    { id: 'medical', labelAr: 'المنظومات الطبية', labelEn: 'Medical Systems' },
  ];

  const filteredProjects = initialProjects.filter(proj => {
    if (selectedCategory === 'all') return true;
    return proj.category === selectedCategory;
  });

  return (
    <section className="py-20 bg-transparent text-slate-900 dark:text-white transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {language === 'ar' ? 'معرض أعمالنا ومشاريعنا' : 'Our Professional Portfolio'}
          </h2>
          <p className="text-slate-600 dark:text-slate-400 font-light text-base sm:text-lg">
            {language === 'ar'
              ? 'مجموعة مختارة من أحدث الأنظمة والحلول البرمجية التي قمنا بتطويرها لعملائنا في مختلف القطاعات بكفاءة وأمان.'
              : 'A curated selection of state-of-the-art enterprise platforms and custom systems developed with perfection.'}
          </p>
          <div className="h-1 w-16 bg-blue-600 dark:bg-blue-500 mx-auto rounded-full mt-4"></div>
        </div>
 
         {/* Categories Tab selector */}
         <div className="flex justify-center flex-wrap gap-2 mb-12">
           {categories.map((cat) => (
             <button
               key={cat.id}
               onClick={() => setSelectedCategory(cat.id)}
               className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 cursor-pointer ${
                 selectedCategory === cat.id
                   ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20 dark:bg-blue-500'
                   : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 dark:bg-white/5 dark:text-slate-300 dark:border-white/10 dark:hover:bg-white/10'
               }`}
             >
               {language === 'ar' ? cat.labelAr : cat.labelEn}
             </button>
           ))}
         </div>
 
         {/* Portfolio Grid */}
         <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
           {filteredProjects.map((project) => (
             <div
               key={project.id}
               className="group cursor-pointer rounded-3xl glass-panel overflow-hidden shadow-sm hover:shadow-xl dark:hover:shadow-blue-950/5 transition-all duration-300 hover:-translate-y-1.5 relative"
               onClick={() => setActiveProject(project)}
             >
               {/* Image box */}
               <div className="relative h-56 overflow-hidden bg-slate-800">
                 <img
                   src={project.image}
                   alt={language === 'ar' ? project.titleAr : project.titleEn}
                   referrerPolicy="no-referrer"
                   className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-60"></div>
                 <span className="absolute top-4 right-4 bg-blue-600 dark:bg-blue-500 text-white text-[9px] font-black uppercase tracking-wider px-3 py-1 rounded-full shadow">
                   {project.category.toUpperCase()}
                 </span>
               </div>
 
               {/* Text content summary */}
               <div className="p-6 space-y-4">
                 <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                   {language === 'ar' ? project.titleAr : project.titleEn}
                 </h3>
                 <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed font-light">
                   {language === 'ar' ? project.descriptionAr : project.descriptionEn}
                 </p>
 
                 {/* Tech Badges */}
                 <div className="flex flex-wrap gap-1.5 pt-2">
                   {project.techStack.slice(0, 3).map((tech, idx) => (
                     <span key={idx} className="bg-slate-50 text-slate-600 dark:bg-[#05070a]/60 dark:text-slate-400 text-[10px] font-medium px-2 py-0.5 rounded border border-slate-100 dark:border-white/5">
                       {tech}
                     </span>
                   ))}
                   {project.techStack.length > 3 && (
                     <span className="bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400 text-[10px] font-semibold px-2 py-0.5 rounded">
                       +{project.techStack.length - 3}
                     </span>
                   )}
                 </div>
 
                 {/* Arrow Action */}
                 <div className="pt-4 flex items-center justify-between text-xs font-bold text-blue-600 dark:text-blue-400 border-t border-slate-100 dark:border-white/10">
                   <span>{language === 'ar' ? 'عرض تفاصيل المشروع الكاملة' : 'View Full Details'}</span>
                   <ExternalLink size={14} />
                 </div>
               </div>
             </div>
           ))}
         </div>
 
         {/* Project Detailed Overlay Modal */}
         {activeProject && (
           <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
             <div className="relative glass-panel rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl animate-scaleIn">
               
               {/* Close Button */}
               <button
                 onClick={() => setActiveProject(null)}
                 className="absolute top-4 right-4 z-10 p-2 rounded-full bg-slate-950/60 text-white hover:bg-slate-950 transition-all cursor-pointer"
                 title={language === 'ar' ? 'إغلاق' : 'Close'}
               >
                 <X size={20} />
               </button>
 
               {/* Master Image Frame */}
               <div className="relative h-64 sm:h-80 w-full bg-slate-800">
                 <img
                   src={activeProject.image}
                   alt={language === 'ar' ? activeProject.titleAr : activeProject.titleEn}
                   referrerPolicy="no-referrer"
                   className="w-full h-full object-cover"
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
                 <div className="absolute bottom-6 left-6 right-6 space-y-2">
                   <span className="bg-blue-600 dark:bg-blue-500 text-white text-[10px] font-extrabold uppercase px-3 py-1 rounded-full">
                     {activeProject.category.toUpperCase()}
                   </span>
                   <h3 className="text-xl sm:text-3xl font-black text-white">
                     {language === 'ar' ? activeProject.titleAr : activeProject.titleEn}
                   </h3>
                 </div>
               </div>
 
               {/* Modal Core Content */}
               <div className="p-6 sm:p-8 space-y-8">
                 
                 {/* Tech Specs Block */}
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-5 rounded-2xl bg-slate-50 dark:bg-[#05070a]/60 border border-slate-100 dark:border-white/5">
                   <div className="space-y-1.5 text-center sm:text-right">
                     <span className="text-[10px] uppercase text-slate-400 font-bold tracking-wider block">
                       {language === 'ar' ? 'نوع قاعدة البيانات' : 'Database Engine'}
                     </span>
                     <span className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200">
                       {activeProject.database}
                     </span>
                   </div>
 
                   <div className="space-y-1.5 text-center sm:text-right">
                     <span className="text-[10px] uppercase text-slate-400 font-bold tracking-wider block">
                       {language === 'ar' ? 'عدد الشاشات واللوحات' : 'Total Screens'}
                     </span>
                     <span className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200">
                       {activeProject.screensCount} {language === 'ar' ? 'شاشة إدخال' : 'Active Screens'}
                     </span>
                   </div>
 
                   <div className="space-y-1.5 text-center sm:text-right">
                     <span className="text-[10px] uppercase text-slate-400 font-bold tracking-wider block">
                       {language === 'ar' ? 'مؤشر أداء السرعة' : 'Speed Performance'}
                     </span>
                     <span className="text-xs sm:text-sm font-black text-emerald-500">
                       {activeProject.performanceScore} (Google Index)
                     </span>
                   </div>
 
                   <div className="space-y-1.5 text-center sm:text-right">
                     <span className="text-[10px] uppercase text-slate-400 font-bold tracking-wider block">
                       {language === 'ar' ? 'تصنيف معيار الأمان' : 'Security Level'}
                     </span>
                     <span className="text-xs sm:text-sm font-black text-indigo-500 dark:text-indigo-400">
                       {activeProject.securityRating}
                     </span>
                   </div>
                 </div>
 
                 {/* Extended Description */}
                 <div className="space-y-3">
                   <h4 className="text-base font-bold text-slate-900 dark:text-white">
                     {language === 'ar' ? 'وصف تفصيلي للمشروع' : 'Full Project Overview'}
                   </h4>
                   <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-light">
                     {language === 'ar' ? activeProject.longDescriptionAr : activeProject.longDescriptionEn}
                   </p>
                 </div>
 
                 {/* Key Features Block */}
                 <div className="space-y-4">
                   <h4 className="text-base font-bold text-slate-900 dark:text-white">
                     {language === 'ar' ? 'الميزات والقدرات الفنية' : 'Key Technical Capabilities'}
                   </h4>
                   <div className="grid sm:grid-cols-2 gap-3.5">
                     {(language === 'ar' ? activeProject.featuresAr : activeProject.featuresEn).map((feat, index) => (
                       <div key={index} className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50/50 dark:bg-white/5 border border-slate-100 dark:border-white/5">
                         <CheckCircle size={16} className="text-blue-500 mt-0.5 flex-shrink-0" />
                         <span className="text-xs font-medium text-slate-700 dark:text-slate-300">{feat}</span>
                       </div>
                     ))}
                   </div>
                 </div>
 
                 {/* Tech Stack tags */}
                 <div className="space-y-3">
                   <h4 className="text-sm font-bold text-slate-500 uppercase tracking-widest">
                     {language === 'ar' ? 'التقنيات المستخدمة في البناء' : 'System Tech Stack'}
                   </h4>
                   <div className="flex flex-wrap gap-2">
                     {activeProject.techStack.map((tech, idx) => (
                       <span key={idx} className="bg-blue-50/75 dark:bg-blue-950/35 border border-blue-100/50 dark:border-blue-900/50 text-blue-700 dark:text-blue-300 text-xs font-bold px-3 py-1 rounded-xl shadow-sm">
                         {tech}
                       </span>
                     ))}
                   </div>
                 </div>
 
                 {/* Client Review Box */}
                 <div className="p-6 rounded-2xl bg-gradient-to-tr from-blue-50 to-indigo-50 dark:from-[#05070a]/60 dark:to-[#05070a]/60 border border-blue-100 dark:border-white/5 space-y-4">
                   <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-blue-200/50 dark:border-slate-800/80 pb-3">
                     <div className="flex flex-col">
                       <span className="text-sm font-black text-slate-900 dark:text-slate-100">
                         {language === 'ar' ? activeProject.clientNameAr : activeProject.clientNameEn}
                       </span>
                       <span className="text-[10px] text-slate-400 font-bold">
                         {language === 'ar' ? 'عميل موثق ومؤكد' : 'Verified Client Testimony'}
                       </span>
                     </div>
                     <div className="flex items-center gap-0.5 text-amber-400">
                       {[...Array(activeProject.clientRating)].map((_, i) => (
                         <Star key={i} size={16} fill="currentColor" />
                       ))}
                     </div>
                   </div>
                   <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 italic leading-relaxed">
                     " {language === 'ar' ? activeProject.clientFeedbackAr : activeProject.clientFeedbackEn} "
                   </p>
                 </div>
 
                 {/* Duration info */}
                 <div className="flex items-center justify-center gap-2 text-xs text-slate-400 font-semibold pt-4">
                   <Clock size={16} />
                   <span>
                     {language === 'ar' 
                       ? `مدة التنفيذ الكلية لهذا النظام: ${activeProject.durationWeeks} أسابيع` 
                       : `Total software delivery timeline: ${activeProject.durationWeeks} Weeks`}
                   </span>
                 </div>
 
               </div>
             </div>
           </div>
         )}

      </div>
    </section>
  );
}
