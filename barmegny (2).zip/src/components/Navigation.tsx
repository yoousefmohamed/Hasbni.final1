import React from 'react';
import { Menu, X, Globe, Sun, Moon, User, ShieldCheck } from 'lucide-react';
import { Language } from '../types';

interface NavigationProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isLoggedIn: boolean;
  onLogout: () => void;
  currentUserRole: 'client' | 'admin' | null;
}

export default function Navigation({
  language,
  setLanguage,
  darkMode,
  setDarkMode,
  activeTab,
  setActiveTab,
  isLoggedIn,
  onLogout,
  currentUserRole,
}: NavigationProps) {
  const [isOpen, setIsOpen] = React.useState(false);

  const navItems = [
    { id: 'home', labelAr: 'الرئيسية', labelEn: 'Home' },
    { id: 'services', labelAr: 'الخدمات', labelEn: 'Services' },
    { id: 'portfolio', labelAr: 'معرض الأعمال', labelEn: 'Portfolio' },
    { id: 'store', labelAr: 'متجر البرمجيات', labelEn: 'Software Store' },
    { id: 'estimate', labelAr: 'اطلب مشروع', labelEn: 'Order Project' },
    { id: 'blog', labelAr: 'المدونة التقنية', labelEn: 'Tech Blog' },
    { id: 'downloads', labelAr: 'مركز التحميل', labelEn: 'Downloads' },
    { id: 'careers', labelAr: 'الوظائف', labelEn: 'Careers' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white/95 dark:bg-[#05070a]/75 backdrop-blur-md border-b border-slate-100 dark:border-white/10 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Brand */}
          <div className="flex-shrink-0 flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-blue-500/30 dark:shadow-blue-500/50">
              ب
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-extrabold bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-400 bg-clip-text text-transparent tracking-tight">
                {language === 'ar' ? 'برمجني' : 'Barmegny'}
              </span>
              <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500 tracking-wider uppercase">
                {language === 'ar' ? 'م. يوسف بلح' : 'Eng. Youssef Balah'}
              </span>
            </div>
          </div>
 
           {/* Desktop Navigation Links */}
           <div className="hidden lg:flex items-center gap-1">
             {navItems.map((item) => (
               <button
                 key={item.id}
                 onClick={() => setActiveTab(item.id)}
                 className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer ${
                   activeTab === item.id
                     ? 'bg-blue-50 text-blue-600 dark:bg-white/5 dark:text-blue-400 font-bold border border-blue-500/10'
                     : 'text-slate-600 hover:text-blue-600 dark:text-slate-300 dark:hover:text-blue-400'
                 }`}
               >
                 {language === 'ar' ? item.labelAr : item.labelEn}
               </button>
             ))}
           </div>

          {/* Controls & Portals */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Language Selector */}
            <button
              onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
              className="p-2 rounded-lg text-slate-500 hover:text-slate-700 hover:bg-slate-50 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:bg-slate-800 transition-all flex items-center gap-1 text-xs font-semibold"
              title={language === 'ar' ? 'Switch to English' : 'تغيير إلى العربية'}
            >
              <Globe size={18} className="text-blue-500" />
              <span>{language === 'ar' ? 'EN' : 'عربي'}</span>
            </button>

            {/* Dark Mode Switcher */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-lg text-slate-500 hover:text-slate-700 hover:bg-slate-50 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:bg-slate-800 transition-all"
            >
              {darkMode ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} className="text-indigo-500" />}
            </button>

            {/* Client / Admin Portals Buttons */}
            {isLoggedIn ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab(currentUserRole === 'admin' ? 'admin' : 'client-portal')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 transition-all shadow-md shadow-blue-500/15"
                >
                  {currentUserRole === 'admin' ? (
                    <>
                      <ShieldCheck size={14} />
                      {language === 'ar' ? 'لوحة التحكم' : 'CMS Admin'}
                    </>
                  ) : (
                    <>
                      <User size={14} />
                      {language === 'ar' ? 'بوابة العميل' : 'Client Portal'}
                    </>
                  )}
                </button>
                <button
                  onClick={onLogout}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold border border-rose-200 text-rose-600 hover:bg-rose-50 dark:border-rose-950 dark:text-rose-400 dark:hover:bg-rose-950/20 transition-all"
                >
                  {language === 'ar' ? 'خروج' : 'Logout'}
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('client-portal')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold border border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
                >
                  <User size={14} className="text-blue-500" />
                  {language === 'ar' ? 'بوابة العميل' : 'Client Login'}
                </button>
                <button
                  onClick={() => setActiveTab('admin')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold bg-slate-900 text-white dark:bg-slate-800 dark:hover:bg-slate-700 hover:bg-slate-800 transition-all"
                >
                  <ShieldCheck size={14} className="text-amber-400" />
                  {language === 'ar' ? 'دخول الإدارة' : 'Admin Area'}
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
              className="p-1.5 rounded text-slate-500 dark:text-slate-400 flex items-center gap-1 text-xs font-bold"
            >
              <Globe size={16} />
              <span>{language === 'ar' ? 'EN' : 'عربي'}</span>
            </button>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-1.5 rounded text-slate-500 dark:text-slate-400"
            >
              {darkMode ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-white dark:bg-[#05070a]/95 backdrop-blur-lg border-t border-slate-100 dark:border-white/10 animate-fadeIn">
          <div className="px-2 pt-2 pb-4 space-y-1 sm:px-3">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsOpen(false);
                }}
                className={`block w-full ${
                  language === 'ar' ? 'text-right' : 'text-left'
                } px-4 py-2.5 rounded-lg text-base font-semibold cursor-pointer ${
                  activeTab === item.id
                    ? 'bg-blue-50 text-blue-600 dark:bg-white/5 dark:text-blue-400 border-l-4 border-blue-500'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5'
                }`}
              >
                {language === 'ar' ? item.labelAr : item.labelEn}
              </button>
            ))}
            
            <div className="border-t border-slate-100 dark:border-slate-800 my-2 pt-2 px-4 space-y-2">
              {isLoggedIn ? (
                <>
                  <button
                    onClick={() => {
                      setActiveTab(currentUserRole === 'admin' ? 'admin' : 'client-portal');
                      setIsOpen(false);
                    }}
                    className="flex items-center justify-center gap-2 w-full py-2.5 rounded-lg text-sm font-bold bg-blue-600 text-white"
                  >
                    {currentUserRole === 'admin' ? (
                      <>
                        <ShieldCheck size={16} />
                        {language === 'ar' ? 'لوحة التحكم' : 'CMS Admin'}
                      </>
                    ) : (
                      <>
                        <User size={16} />
                        {language === 'ar' ? 'بوابة العميل' : 'Client Portal'}
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => {
                      onLogout();
                      setIsOpen(false);
                    }}
                    className="block w-full text-center py-2 rounded-lg text-sm font-semibold border border-rose-200 text-rose-600"
                  >
                    {language === 'ar' ? 'خروج' : 'Logout'}
                  </button>
                </>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      setActiveTab('client-portal');
                      setIsOpen(false);
                    }}
                    className="flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold border border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-200"
                  >
                    <User size={14} />
                    {language === 'ar' ? 'بوابة العميل' : 'Client'}
                  </button>
                  <button
                    onClick={() => {
                      setActiveTab('admin');
                      setIsOpen(false);
                    }}
                    className="flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold bg-slate-900 text-white"
                  >
                    <ShieldCheck size={14} />
                    {language === 'ar' ? 'الإدارة' : 'Admin'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
