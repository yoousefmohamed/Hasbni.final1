import { Service, Project, BlogPost, DownloadItem, ClientProjectState } from './types';

export const services: Service[] = [
  {
    id: 'accounting',
    titleAr: 'تصميم برامج محاسبة ذكية',
    titleEn: 'Smart Accounting Software Design',
    descriptionAr: 'تصميم وتطوير برمجيات محاسبية متكاملة تضمن دقة القيود والتقارير المالية والتحكم التام في الحسابات والأصول.',
    descriptionEn: 'Develop custom accounting software ensuring precise entries, financial reporting, and comprehensive asset control.',
    icon: 'Calculator',
    category: 'accounting',
    featuresAr: [
      'نظام قيود محاسبية مزدوجة تلقائي',
      'إدارة النقدية والبنوك والشيكات',
      'إصدار الفواتير الإلكترونية المعتمدة للضرائب',
      'تقارير القوائم المالية والميزانية العمومية بضغطة زر',
      'مستويات أمان متكاملة وصلاحيات للمستخدمين'
    ],
    featuresEn: [
      'Automated double-entry bookkeeping',
      'Cash, bank, and check management',
      'E-invoice generation compliant with tax systems',
      'Financial statement & balance sheet reports in one click',
      'Comprehensive security access levels and permissions'
    ]
  },
  {
    id: 'erp',
    titleAr: 'أنظمة ERP السحابية والمحلية',
    titleEn: 'Cloud & Local ERP Systems',
    descriptionAr: 'أنظمة تخطيط موارد المؤسسات المتكاملة التي تربط كافة الأقسام (المبيعات، المخازن، المشتريات، الموارد البشرية والمالية) في منصة موحدة.',
    descriptionEn: 'Integrated Enterprise Resource Planning linking sales, inventory, purchasing, HR, and finance in a unified platform.',
    icon: 'Layers',
    category: 'enterprise',
    featuresAr: [
      'إدارة الموارد البشرية والحضور والرواتب',
      'إدارة المشتريات والموردين',
      'تحديث فوري لبيانات الأقسام',
      'لوحة قيادة تفاعلية ذكية للرؤساء التنفيذيين',
      'الربط مع الفروع والأنظمة الخارجية عبر APIs'
    ],
    featuresEn: [
      'HR, payroll, and attendance tracking',
      'Vendor and purchasing workflow automation',
      'Real-time data synchronization across sections',
      'Interactive executive dashboards',
      'Multi-branch connection and external API integrations'
    ]
  },
  {
    id: 'pos',
    titleAr: 'أنظمة كاشير ونقاط البيع POS',
    titleEn: 'POS & Cashier Systems',
    descriptionAr: 'أنظمة نقاط بيع فائقة السرعة مصممة لمحلات التجزئة، السوبر ماركت، والصيدليات مع إمكانية العمل بدون اتصال بالإنترنت.',
    descriptionEn: 'Ultra-fast Point of Sale systems optimized for retail, supermarkets, and pharmacies, featuring offline support.',
    icon: 'ShoppingCart',
    category: 'retail',
    featuresAr: [
      'شاشة مبيعات سريعة تدعم قارئ الباركود والموازين',
      'دعم كامل للفواتير المبسطة وضريبة القيمة المضافة',
      'جرد المخازن اللحظي وإشعارات بنقص الكميات',
      'دعم العمل عند انقطاع الإنترنت والمزامنة التلقائية',
      'لوحة تحكم إدارية سحابية لمتابعة المبيعات فورياً'
    ],
    featuresEn: [
      'Rapid sales checkout supporting barcodes & scales',
      'Simplified invoice & VAT compliance',
      'Real-time inventory deduction and low-stock alerts',
      'Seamless offline mode with automatic background sync',
      'Cloud dashboard for instant remote sales tracking'
    ]
  },
  {
    id: 'restaurants',
    titleAr: 'إدارة المطاعم والكافيهات',
    titleEn: 'Restaurant & Cafe Management',
    descriptionAr: 'نظام كاشير متطور للمطاعم والكافيهات يدعم الطاولات، صالة الطعام، التوصيل، المطبخ، والتطبيقات المحمولة.',
    descriptionEn: 'Advanced restaurant management supporting table services, takeaway, delivery, kitchen screens, and mobile apps.',
    icon: 'Coffee',
    category: 'retail',
    featuresAr: [
      'تصميم مرن لخريطة الطاولات وتوزيع طلبات الصالة',
      'شاشات تحضير متكاملة للمطبخ لتسريع إعداد الطلبات',
      'إدارة مكونات الوجبات والتكاليف (Recipe Costs)',
      'إدارة كباتن التوصيل وعملاء الدليفري بدقة',
      'نظام طلبات ذاتي عبر الويب أو QR Code'
    ],
    featuresEn: [
      'Dynamic table layouts and seating allocation',
      'Digital kitchen displays to accelerate preparations',
      'Ingredient-level costing and recipe management',
      'Delivery agent dispatch and customer mapping',
      'Self-ordering system via mobile web or QR Codes'
    ]
  },
  {
    id: 'medical',
    titleAr: 'إدارة الصيدليات والعيادات الطبية',
    titleEn: 'Pharmacy & Medical Clinic Management',
    descriptionAr: 'أنظمة متكاملة لتنظيم المواعيد، ملفات المرضى، الوصفات الطبية، وجرد الأدوية وتواريخ صلاحيتها.',
    descriptionEn: 'Comprehensive medical systems organizing appointments, patient history, prescriptions, drug batches, and expiry dates.',
    icon: 'Activity',
    category: 'medical',
    featuresAr: [
      'السجل الطبي الإلكتروني الشامل للمريض (EMR)',
      'إدارة حجز المواعيد وتنظيم غرف الانتظار',
      'جرد الصيدلية الذكي بباركود الأدوية والبدائل الكيميائية',
      'الربط مع شركات التأمين الصحي ونسب التحمل',
      'تنبيهات تاريخ الصلاحية للأدوية والمنتجات الطبية'
    ],
    featuresEn: [
      'Comprehensive Electronic Medical Records (EMR)',
      'Appointment scheduling and waiting room queues',
      'Smart pharmacy catalog with barcode substitutes',
      'Insurance company integration and co-payment tiers',
      'Batch expiry alerts for safe drug management'
    ]
  },
  {
    id: 'web_dev',
    titleAr: 'المواقع والمتاجر الإلكترونية المتطورة',
    titleEn: 'Advanced Websites & E-Commerce',
    descriptionAr: 'تصميم مواقع ويب تعريفية ومتاجر إلكترونية احترافية مخصصة لتحقيق أعلى سرعة تصفح وأداء متميز لـ SEO.',
    descriptionEn: 'Design custom corporate websites and feature-rich e-commerce shops optimized for high speed and SEO dominance.',
    icon: 'Globe',
    category: 'web_mobile',
    featuresAr: [
      'بناء واجهات حديثة متجاوبة 100% مع كافة الشاشات',
      'التكامل مع بوابات الدفع (Stripe, PayPal, Paymob وغيرها)',
      'لوحة تحكم إدارية سهلة الاستعمال لإدارة المنتجات والطلبات',
      'أكواد نظيفة ومهيأة بالكامل لمحركات البحث وجوجل',
      'أداء سريع جداً يعتمد على خوادم فائقة السرعة وعالمية'
    ],
    featuresEn: [
      'Highly responsive frontend layouts for all devices',
      'Integrated payment gateways (Stripe, Paymob, PayPal, etc.)',
      'User-friendly administration system to manage products',
      'SEO-semantic clean coding structures',
      'Lightning-fast page loading scores and global performance'
    ]
  },
  {
    id: 'ai_automation',
    titleAr: 'الذكاء الاصطناعي والأتمتة',
    titleEn: 'Artificial Intelligence & Automation',
    descriptionAr: 'إدماج خوارزميات الذكاء الاصطناعي وبوتات الدردشة الذكية لتقديم أفضل خدمة عملاء وتحسين إنتاجية العمل.',
    descriptionEn: 'Injecting custom AI algorithms and intelligent chatbots to deliver brilliant client support and elevate workflows.',
    icon: 'Cpu',
    category: 'ai_dev',
    featuresAr: [
      'مساعدون ذكيون للإجابة التلقائية على العملاء',
      'تحليل البيانات المالية والتنبؤ بالمبيعات المستقبلية',
      'أتمتة العمليات المتكررة وسحب البيانات الذكي',
      'تكامل مع واجهات برمجة التطبيقات للذكاء الاصطناعي',
      'تصنيف البيانات والمستندات تلقائياً'
    ],
    featuresEn: [
      'Intelligent digital assistants answering clients 24/7',
      'Financial data analysis and sales forecasting',
      'Robotic process automation for repetitive tasks',
      'Custom API integrations with Gemini, OpenAI, etc.',
      'Automated document classification and OCR'
    ]
  }
];

export const initialProjects: Project[] = [
  {
    id: 'b-erp',
    titleAr: 'نظام برمجني ERP للشركات الكبرى',
    titleEn: 'Barmegny ERP for Major Enterprises',
    descriptionAr: 'نظام ERP متكامل يربط المبيعات والمخازن والمالية لشركة تجارية تمتلك 14 فرعاً مع تحديث لحظي للمخزون.',
    descriptionEn: 'A comprehensive ERP linking sales, storage, and finance for a commercial firm with 14 branches and live sync.',
    longDescriptionAr: 'يعتبر نظام برمجني ERP الحل الأمثل لإدارة المجموعات والشركات متعددة الفروع. يوفر لوحة قيادة مركزية لمراقبة العمليات والمبيعات والمخزون في الوقت الفعلي مع توافق كامل مع الفاتورة الإلكترونية السعودية والمصرية والخليجية ونظام الربط والفلترة مع مصلحة الضرائب.',
    longDescriptionEn: 'Barmegny ERP is the perfect solution for multi-branch firms. It provides a centralized master control panel for tracking real-time sales and inventory, with 100% compliance with Gulf/Arab tax authorities and e-invoicing systems.',
    category: 'erp',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=600',
    techStack: ['ASP.NET Core 9 Web API', 'React 19', 'TypeScript', 'Tailwind CSS', 'SQL Server', 'Redis', 'Docker'],
    screensCount: 42,
    database: 'Microsoft SQL Server',
    performanceScore: '98%',
    securityRating: 'A+ Class',
    durationWeeks: 12,
    clientNameAr: 'مجموعة الفوزان للتجارة',
    clientNameEn: 'Al-Fozan Trading Group',
    clientFeedbackAr: 'النظام أحدث نقلة نوعية في إدارة فروعنا. أصبح بإمكاننا جرد المخازن في ثوان ومتابعة أرباحنا اليومية بدقة تناهز 100%. شكراً للمهندس يوسف بلح وفريق العمل.',
    clientFeedbackEn: 'This ERP revolutionized our workflow. We can audit all branch inventory in seconds and track our absolute daily profits. Many thanks to Eng. Youssef Balah.',
    clientRating: 5,
    featuresAr: [
      'الربط التلقائي واللحظي بين 14 فرعاً ومخزناً رئيسياً',
      'إصدار الفاتورة الإلكترونية والربط مع الهيئات الضريبية',
      'حساب تلقائي لضريبة القيمة المضافة وإصدار الإقرارات',
      'نظام أجور ذكي للموظفين وبصمات الحضور والانصراف',
      'نظام محاسبة تكاليف متقدم لتحديد ربحية خطوط الإنتاج'
    ],
    featuresEn: [
      'Live seamless sync between 14 physical branches and master store',
      'E-invoice generation and direct API integration with tax bureaus',
      'Automated VAT calculation and comprehensive tax reporting',
      'Advanced biometric attendance and payroll software module',
      'Cost accounting system tracking precise production margin'
    ],
    images: [
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=600',
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=600',
      'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?q=80&w=600'
    ]
  },
  {
    id: 'pos-cloud',
    titleAr: 'نظام كاشير برمجني POS السحابي للمطاعم',
    titleEn: 'Barmegny POS Cloud for Restaurants',
    descriptionAr: 'تطبيق ويب وسطح مكتب متكامل لإدارة الطلبيات والمطابخ بنظام نقاط بيع تفاعلي وسهل الاستخدام للغاية.',
    descriptionEn: 'Interactive and user-friendly web & desktop system managing restaurant orders, deliveries, and kitchens.',
    longDescriptionAr: 'نظام متكامل لإدارة المطاعم الفاخرة والكافيهات السريعة. يعمل محلياً في الصالة لضمان السرعة الفائقة مع مزامنة سحابية لحفظ التقارير والمبيعات. يدعم شاشات تحضير المطبخ وتطبيق الهاتف للقرصان والنظام الكلي للدليفري.',
    longDescriptionEn: 'Full-featured suite designed for fine dining and quick-service cafes. Operates locally for instant speed while syncing with the cloud to store analytical datasets securely. Supports kitchen monitors, waiter apps, and complete home delivery dispatch.',
    category: 'pos',
    image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?q=80&w=600',
    techStack: ['C# .NET 9 WPF', 'React', 'Tailwind CSS', 'PostgreSQL', 'SignalR', 'SQLite'],
    screensCount: 18,
    database: 'PostgreSQL & SQLite (Local)',
    performanceScore: '99%',
    securityRating: 'High-Level JWT',
    durationWeeks: 8,
    clientNameAr: 'سلسلة مطاعم قصر الياسمين',
    clientNameEn: 'Al-Yasmine Restaurant Chain',
    clientFeedbackAr: 'سرعة كاشير برمجني خيالية وميزة تشغيل المطبخ قللت الأخطاء تماماً. نوصي بالتعامل مع م. يوسف بلح بشدة لالتزامه بالاحترافية.',
    clientFeedbackEn: 'Barmegny POS speed is incredible, and kitchen monitors slashed order errors to zero. We highly recommend Eng. Youssef Balah.',
    clientRating: 5,
    featuresAr: [
      'إدارة الصالة وحجوزات الطاولات بشاشة تفاعلية باللمس',
      'شاشة المطبخ الفورية لتلقي الطلبات وإتمامها',
      'إدارة الـ Recipes وهدر المواد الأولية في المخزن',
      'نظام تقارير الأرباح والمصروفات والشيفتات اليومية للكاشير',
      'تطبيق مخصص للويترز لطلب الأوردر مباشرة من الطاولة'
    ],
    featuresEn: [
      'Interactive visual touch layout for dining tables',
      'Real-time kitchen displays for instant kitchen orders',
      'In-depth recipe building and waste percentage audits',
      'Dynamic shift reports, cashier cash registers, and expenses',
      'Specialized application for table waiters to place orders directly'
    ],
    images: [
      'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?q=80&w=600',
      'https://images.unsplash.com/photo-1556742111-a301076d9d18?q=80&w=600'
    ]
  },
  {
    id: 'pharma-care',
    titleAr: 'منظومة إدارة الصيدليات الكبرى',
    titleEn: 'PharmaCare Enterprise Management',
    descriptionAr: 'برنامج إدارة الصيدليات الذكي المزود بقاعدة بيانات أدوية ضخمة وبدائل الأدوية ومتابعة تواريخ الصلاحية والانتهاء.',
    descriptionEn: 'Intelligent pharmacy management software featuring a massive drug database, chemical substitutes, and shelf-life tracking.',
    longDescriptionAr: 'برنامج PharmaCare لإدارة الصيدليات يمنح الصيادلة السيطرة الكاملة على آلاف الأدوية والمستلزمات الطبية مع ربط ذكي بقارئ الباركود وميزان المبيعات وبوابات شركات التأمين الصحي ونظام الأرباح والمشتروات الدقيقة.',
    longDescriptionEn: 'PharmaCare system gives pharmacists ultimate authority over thousands of medical products. Features barcode scanners, scale connections, medical insurance systems, and precise profit auditing modules.',
    category: 'medical',
    image: 'https://images.unsplash.com/photo-1631549916768-4119b2e55c06?q=80&w=600',
    techStack: ['ASP.NET Core', 'C#', 'SQL Server', 'React', 'TypeScript', 'CSS Grid'],
    screensCount: 25,
    database: 'MS SQL Server',
    performanceScore: '97%',
    securityRating: 'Military-Grade TLS',
    durationWeeks: 10,
    clientNameAr: 'صيدليات الشفاء الحديثة',
    clientNameEn: 'Al-Shifa Modern Pharmacies',
    clientFeedbackAr: 'أفضل برنامج صيدليات جربناه على الإطلاق. قاعدة الأدوية مجهزة مسبقاً والبدائل تساعدنا كثيراً في توفير الحلول للمرضى بامتياز.',
    clientFeedbackEn: 'The best pharmacy tool we have ever used. Pre-loaded drug database and Chemical Alternatives save so much time in assisting our patients.',
    clientRating: 5,
    featuresAr: [
      'قاعدة بيانات جاهزة تحتوي على أكثر من 30 ألف دواء',
      'دليل البدائل الكيميائية والمماثلات الفعالة للأدوية الناقصة',
      'تنبيهات تلقائية قبل 6 أشهر من انتهاء صلاحية أي عبوة دواء',
      'إدارة المبيعات السريعة وحساب خصومات المرضى والنقاط',
      'ربط مبيعات التأمين الصحي ونظام التحصيل والدفع الآجل'
    ],
    featuresEn: [
      'Ready-made medical database containing 30,000+ items',
      'Chemical substitutes module to find alternative active molecules',
      'Automated proactive warnings 6 months before batch expiration',
      'Fast sales screen with loyalty points and custom discounts',
      'Insurance accounts tracking, copayments, and outstanding invoices'
    ],
    images: [
      'https://images.unsplash.com/photo-1631549916768-4119b2e55c06?q=80&w=600',
      'https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=600'
    ]
  }
];

export const initialBlogPosts: BlogPost[] = [
  {
    id: 'erp-importance',
    titleAr: 'لماذا تحتاج شركتك إلى نظام تخطيط الموارد ERP؟',
    titleEn: 'Why Your Company Needs an ERP Planning System',
    contentAr: 'تخطيط موارد المؤسسات (ERP) ليس مجرد رفاهية بل هو عصب الشركات الحديثة. في هذه المقالة نستعرض كيف يساعد نظام ERP في دمج العمليات من الحسابات والمخازن للمبيعات، وبالتالي تقليل الهدر وزيادة الأرباح بنسبة تفوق 35%...',
    contentEn: 'Enterprise Resource Planning (ERP) is not just a luxury but the spine of modern organizations. In this article, we explore how an ERP integrates your accounts, stock, and sales to slash overheads and boost margins by up to 35%...',
    category: 'ERP Systems',
    authorAr: 'م. يوسف بلح',
    authorEn: 'Eng. Youssef Balah',
    date: '2026-07-15',
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=600',
    tags: ['ERP', 'المحاسبة', 'أتمتة الأعمال'],
    views: 1240
  },
  {
    id: 'pos-offline-tech',
    titleAr: 'كيف تضمن استمرار نظام الكاشير POS عند انقطاع الإنترنت؟',
    titleEn: 'Ensuring Your POS System Operates Without Internet',
    contentAr: 'انقطاع الإنترنت في نقطة البيع قد يعطل نشاطك التجاري ويسبب خسائر بالغة. سنتناول التقنيات الهجينة لتشغيل قواعد البيانات المحلية SQLite ثم المزامنة تلقائياً مع خوادم SQL Server السحابية فور عودة الاتصال...',
    contentEn: 'Internet disruption at the point of sale can paralyze your retail workflow. We will analyze how hybrid technologies utilize local SQLite databases and automatically sync with cloud SQL Server structures once online...',
    category: 'Cashier Tech',
    authorAr: 'م. يوسف بلح',
    authorEn: 'Eng. Youssef Balah',
    date: '2026-07-18',
    image: 'https://images.unsplash.com/photo-1556740758-90de374c12ad?q=80&w=600',
    tags: ['POS', 'Cloud Sync', 'C# .NET'],
    views: 950
  },
  {
    id: 'ai-accounting-future',
    titleAr: 'الذكاء الاصطناعي في برامج المحاسبة: الثورة القادمة',
    titleEn: 'AI in Accounting Software: The Impending Revolution',
    contentAr: 'كيف سيغير الذكاء الاصطناعي مهنة المحاسبة؟ من المطابقة الآلية للحسابات البنكية واستخلاص النصوص والبيانات من الفواتير الورقية تلقائياً بواسطة خوارزميات الذكاء الاصطناعي والتعرف الضوئي OCR لسرعة الإدخال...',
    contentEn: 'How will artificial intelligence transform accounting? From automatic bank statement reconciliation to optical character recognition (OCR) extracting invoices, AI is boosting data entry speeds globally...',
    category: 'AI & Accounting',
    authorAr: 'م. يوسف بلح',
    authorEn: 'Eng. Youssef Balah',
    date: '2026-07-19',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=600',
    tags: ['AI', 'الذكاء الاصطناعي', 'المحاسبة الإلكترونية'],
    views: 820
  }
];

export const initialDownloads: DownloadItem[] = [
  {
    id: 'pos-demo',
    titleAr: 'نسخة تجريبية من برنامج كاشير برمجني POS',
    titleEn: 'Barmegny POS - Desktop Trial Version',
    descriptionAr: 'قم بتحميل النسخة التجريبية المجانية من برنامج الكاشير ونقاط البيع واستمتع بأداء فائق السرعة وجرد متطور للمخازن.',
    descriptionEn: 'Download the free trial of our Point of Sale system. Experience fast checkout and advanced inventory control.',
    fileSize: '45.2 MB',
    version: 'v4.2.1',
    type: 'installer',
    downloadUrl: '#',
    downloadsCount: 1420
  },
  {
    id: 'erp-user-guide',
    titleAr: 'دليل استخدام نظام برمجني ERP الشامل (PDF)',
    titleEn: 'Barmegny ERP Comprehensive User Manual (PDF)',
    descriptionAr: 'كتيب تعليمي مفصل يشرح كافة أقسام نظام تخطيط موارد المؤسسات ERP، من القيود المحاسبية إلى إدارة الموارد البشرية والمخازن.',
    descriptionEn: 'Detailed instructional booklet describing all ERP modules, from general ledgers and invoicing to HR and inventory.',
    fileSize: '8.4 MB',
    version: '2026 Edition',
    type: 'pdf',
    downloadUrl: '#',
    downloadsCount: 890
  },
  {
    id: 'tax-excel-template',
    titleAr: 'نموذج إكسل ذكي لحساب ضريبة القيمة المضافة',
    titleEn: 'VAT Calculation Smart Excel Template',
    descriptionAr: 'قالب إكسل جاهز مصمم لمساعدة أصحاب الشركات الصغيرة في مراجعة وحساب ضريبة القيمة المضافة وإعداد الإقرار الضريبي بسهولة.',
    descriptionEn: 'Ready-to-use smart Excel spreadsheet helping small business owners compute VAT payments and outline quarterly tax filing.',
    fileSize: '1.2 MB',
    version: 'v2.0',
    type: 'excel_template',
    downloadUrl: '#',
    downloadsCount: 2310
  }
];

export const initialClientProjects: ClientProjectState[] = [
  {
    id: 'cl-proj-1',
    titleAr: 'منظومة محاسبية متكاملة - عيادات الأمل',
    titleEn: 'Integrated Accounting - Al-Amal Clinics',
    clientEmail: 'client@alamal.com',
    clientName: 'د. خالد عبد الرحمن',
    progress: 75,
    status: 'testing',
    invoices: [
      { id: 'INV-1001', amount: 1500, dueDate: '2026-06-01', status: 'paid' },
      { id: 'INV-1002', amount: 1500, dueDate: '2026-07-20', status: 'unpaid' }
    ],
    updates: [
      {
        date: '2026-07-10',
        titleAr: 'الانتهاء من ربط الصيدلية',
        titleEn: 'Pharmacy Module Finished',
        descriptionAr: 'تم بنجاح الانتهاء من ربط مخزن صيدلية العيادات وتفعيل نظام بدائل الأدوية بنسبة 100%.',
        descriptionEn: 'The clinic pharmacy inventory mapping is successfully finalized and chemical substitutes are fully activated.'
      },
      {
        date: '2026-07-05',
        titleAr: 'اكتمال واجهات حجز المواعيد',
        titleEn: 'Appointment UI Complete',
        descriptionAr: 'تم تفعيل حجز مواعيد المرضى ولوحات الطبيب والانتظار وتجربتها بكفاءة عالية.',
        descriptionEn: 'Patient registration, doctor desks, and waiting area queue screens are successfully launched and tested.'
      }
    ],
    chatHistory: [
      { sender: 'support', message: 'مرحباً د. خالد، تم تفعيل لوحة شاشة حجز المواعيد اليوم. هل تم اختبارها من قبل موظف الاستقبال؟', timestamp: '10:30 AM' },
      { sender: 'client', message: 'أهلاً بك م. يوسف. نعم قمنا بتجربتها وهي مريحة جداً وسريعة. ننتظر تفعيل خيارات الدفع.', timestamp: '11:15 AM' },
      { sender: 'support', message: 'ممتاز جداً، خيارات الدفع والربط مع الفيزا في مرحلة الاختبار النهائي الآن وسننتهي منها غداً.', timestamp: '11:20 AM' }
    ],
    contracts: [
      {
        id: 'CTR-9021',
        titleAr: 'عقد توريد وبرمجة منظومة محاسبية سحابية',
        titleEn: 'Cloud Accounting System Licensing and Customization Agreement',
        signDate: '2026-05-12',
        status: 'signed',
        downloadUrl: '#'
      }
    ],
    latestBuilds: [
      {
        version: 'v1.4.2-beta',
        releaseDate: '2026-07-16',
        notesAr: 'إصلاح مشكلة جرد أدوية البدائل وإضافة طباعة الإقرارات.',
        notesEn: 'Fixed batch alternative chemical lookups and added tax report printing support.',
        fileSize: '32.1 MB',
        downloadUrl: '#'
      }
    ],
    supportTickets: [
      {
        id: 'TCK-4081',
        subjectAr: 'طلب ربط جهاز قارئ الباركود الجديد',
        subjectEn: 'Support connecting our custom Zebra barcode scanner model',
        status: 'resolved',
        createdAt: '2026-07-14'
      },
      {
        id: 'TCK-5012',
        subjectAr: 'بطء بسيط في طباعة التقارير المالية الكبيرة',
        subjectEn: 'Optimizing balance sheet query load times',
        status: 'open',
        createdAt: '2026-07-18'
      }
    ]
  }
];
